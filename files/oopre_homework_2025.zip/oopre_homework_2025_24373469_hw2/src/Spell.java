public class Spell implements Item {
    private String id;
    private int manaCost;
    private int power;
    private String type;

    public Spell(String id, int manaCost, int power, String type) {
        this.id = id;
        this.manaCost = manaCost;
        this.power = power;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public int getManaCost() {
        return manaCost;
    }

    public int getPower() {
        return power;
    }

    public String getTypeName() {
        return type;
    }

    public void use(Adventurer user, Adventurer target) {

    }

    public boolean useable() {
        return true;
    }
}
