interface Item {
    String getId();

    String getTypeName();

    boolean useable();

    void use(Adventurer user, Adventurer target);
}
