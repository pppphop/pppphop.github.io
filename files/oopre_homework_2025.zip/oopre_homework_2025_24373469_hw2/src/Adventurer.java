import java.util.ArrayList;

public class Adventurer {
    private String id;
    private int hitpoint;
    private int atk;
    private int def;
    private int mana;
    private int isDead;
    private ArrayList<Bottle> bottles;
    private ArrayList<Equipment> equipments;
    private ArrayList<Item> backpack;
    private ArrayList<Spell> spells;

    public Adventurer(String id) {
        this.id = id;
        this.hitpoint = 500;
        this.atk = 1;
        this.def = 0;
        this.mana = 10;
        this.bottles = new ArrayList<Bottle>();
        this.equipments = new ArrayList<Equipment>();
        this.backpack = new ArrayList<>();
        this.isDead = 0;
        this.spells = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void addBottle(Bottle bottle) {
        bottles.add(bottle);
    }

    public void addEquipment(Equipment equipment) {
        equipments.add(equipment);
    }

    public int bottlenum() {
        return bottles.size();
    }

    public int equipmentnum() {
        return equipments.size();
    }

    public int delBottle(String delid) {
        for (Bottle b : bottles) {
            if (b.getId().equals(delid)) {
                int res = b.getEffect();
                bottles.remove(b);
                return res;
            }
        }
        return 0;
    }

    public void delEquipment(String delid) {
        for (Equipment e : equipments) {
            if (e.getId().equals(delid)) {
                equipments.remove(e);
                break;
            }
        }
    }

    public void addhitpoint(int hitpoint) {
        this.hitpoint += hitpoint;
    }

    public void subhitpoint(int hitpoint) {
        this.hitpoint -= hitpoint;
    }

    public void addatk(int atk) {
        this.atk += atk;
    }

    public void subatk(int atk) {
        this.atk -= atk;
    }

    public void adddef(int def) {
        this.def += def;
    }

    public void subdef(int def) {
        this.def -= def;
    }

    public void addmana(int mana) {
        this.mana += mana;
    }

    public void submana(int mana) {
        this.mana -= mana;
    }

    public int gethitpoint() {
        return hitpoint;
    }

    public int getatk() {
        return atk;
    }

    public int getdef() {
        return def;
    }

    public int getmana() {
        return mana;
    }

    public void setatkzero() {
        this.atk = 0;
    }

    public String additem(String item) {
        String res = "";
        int fl = 0;
        for (Item i : bottles) {
            if (i.getId().equals(item)) {
                res = i.getTypeName();
                fl = 1;
                backpack.add(i);
                break;
            }
        }
        if (fl == 0) {
            for (Item i : equipments) {
                if (i.getId().equals(item)) {
                    res = i.getTypeName();
                    backpack.add(i);
                    break;
                }
            }
        }
        return res;
    }

    public String delitem(String item) {
        String res = "";
        for (Item i : backpack) {
            if (i.getId().equals(item)) {
                res = i.getTypeName();
                backpack.remove(i);
                break;
            }
        }
        return res;
    }

    public int backpacknum() {
        return backpack.size();
    }

    public int itemnum() {
        return backpack.size() + spells.size();
    }

    public void setHitpointzero() {
        this.hitpoint = 0;
        this.isDead = 1;
    }

    public int checkdead() {
        if (this.hitpoint <= 0) {
            this.isDead = 1;
        }
        return  this.isDead;
    }

    public boolean useitem(String item,Adventurer target) {
        boolean fl = false;
        if (target.checkdead() == 1) {
            return fl;
        }
        for (Item i : backpack) {
            if (i.getId().equals(item)) {
                if (i.useable()) {
                    i.use(this,target);
                    fl = true;
                }
                break;
            }
        }
        if (!fl) {
            for (Item i : spells) {
                if (i.getId().equals(item)) {
                    i.use(this,target);
                    fl = true;
                }
                break;
            }
        }
        return fl;
    }

    public void addspell(Spell spell) {
        spells.add(spell);
    }

    public int spellnum() {
        return spells.size();
    }
}
