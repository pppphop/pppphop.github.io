import java.util.ArrayList;

public class BattleManager {
    private Adventurer atker;
    private ArrayList<Adventurer> targets;

    public BattleManager(Adventurer atker,ArrayList<Adventurer> targets) {
        this.atker = atker;
        this.targets = targets;
    }

    public boolean fight() {
        if (atker.checkdead() == 1) {
            return false;
        }
        int maxDef = 0;
        boolean success = false;
        for (Adventurer adv : targets) {
            if (adv.getFinalDef() > maxDef) {
                maxDef = adv.getFinalDef();
            }
        }
        if (atker.getWeapon() instanceof Magicbook) {
            int manacost = (int) Math.ceil(Math.sqrt(atker.getWeapon().getce()));
            if (atker.getmana() >= manacost) {
                success = true;
                atker.submana(manacost);
                for (Adventurer target : targets) {
                    int damage = atker.getFinalAtk();
                    if (target.gethitpoint() > damage) {
                        target.subhitpoint(damage);
                    }
                    else {
                        target.setHitpointzero();
                        atker.addMoney(calculateReward(target));
                    }
                }
            }
        }
        else {
            int damage = atker.getFinalAtk() - maxDef;
            if (damage > 0) {
                success = true;
                for (Adventurer target : targets) {
                    if (target.gethitpoint() > damage) {
                        target.subhitpoint(damage);
                    }
                    else {
                        target.setHitpointzero();
                        atker.addMoney(calculateReward(target));
                    }
                }
            }
        }
        return success;
    }

    private int calculateReward(Adventurer target) {
        int sum = 0;
        sum += target.getMoney();
        sum += target.effectsum();
        sum += target.cesum();
        return  sum;
    }
}
