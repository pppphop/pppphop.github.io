import org.junit.Test;
import static org.junit.Assert.*;

public class AdventurerTest {

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    @Test
    public void getId() {
        Adventurer adv=new Adventurer("2025");
        assertEquals("2025",adv.getId());
    }

    @Test
    public void addBottle() {
        Adventurer adv=new Adventurer("Alice");
        assertEquals(0,adv.bottlenum());

        Bottle bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        Bottle bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
    }

    @Test
    public void addEquipment() {
        Adventurer adv=new Adventurer("2025");
        Equipment equip1=new Equipment("equip1");
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        Equipment equip2=new Equipment("equip2");
        adv.addEquipment(equip2);
        assertEquals(2,adv.equipmentnum());
    }

    @Test
    public void bottlenum() {
    }

    @Test
    public void equipmentnum() {
    }

    @org.junit.Test
    public void delBottle() {
        Adventurer adv=new Adventurer("Alice");
        assertEquals(0,adv.bottlenum());

        Bottle bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        Bottle bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
        adv.delBottle("bottle2");
        assertEquals(1,adv.bottlenum());
        adv.delBottle("bottle1");
        assertEquals(0,adv.bottlenum());
        bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
        adv.delBottle("bottle1");
        assertEquals(1,adv.bottlenum());
        adv.delBottle("bottle2");
        assertEquals(0,adv.bottlenum());
    }

    @org.junit.Test
    public void delEquipment() {
        Adventurer adv=new Adventurer("2025");
        Equipment equip1=new Equipment("equip1");
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        Equipment equip2=new Equipment("equip2");
        adv.addEquipment(equip2);
        assertEquals(2,adv.equipmentnum());
        adv.delEquipment("equip1");
        assertEquals(1,adv.equipmentnum());
        adv.delEquipment("equip2");
        assertEquals(0,adv.equipmentnum());
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        adv.delEquipment("equip1");
        assertEquals(0,adv.equipmentnum());
    }

    @Test
    public void additem(){
        Adventurer adv=new Adventurer("2025");
        Bottle bottle1=new HpBottle("HpBottle1",1);
        adv.addBottle(bottle1);
        assertEquals(0,adv.backpacknum());
        Equipment e=new Equipment("equip1");
        adv.addEquipment(e);
        adv.additem("equip1");
        assertEquals(1,adv.backpacknum());
        adv.additem("HpBottle1");
        assertEquals(2,adv.backpacknum());
        Spell sp = new HealSpell("heal",1,200,"HealSpell");
        adv.addspell(sp);
        assertEquals(2,adv.backpacknum());
        Bottle bottle2=new AtkBottle("AtkBottle1",2);
        adv.addBottle(bottle2);
        adv.additem("AtkBottle1");
        assertEquals(3,adv.backpacknum());
        adv.delitem("AtkBottle1");
        assertEquals(2,adv.backpacknum());
        adv.delitem("HpBottle1");
        assertEquals(1,adv.backpacknum());
        adv.delitem("equip1");
        assertEquals(0,adv.backpacknum());
    }

    @Test
    public void useitem(){
        Adventurer adv=new Adventurer("2025");
        Adventurer adv2=new Adventurer("2026");
        Bottle bottle1=new HpBottle("HpBottle1",1);
        adv.addBottle(bottle1);
        adv.additem("HpBottle1");
        adv.useitem("HpBottle1",adv2);
        assertEquals(0,adv.backpacknum());
        assertEquals(501,adv2.gethitpoint());
        Spell sp = new HealSpell("heal",1,200,"HealSpell");
        adv.addspell(sp);
        adv.additem("heal");
        assertEquals(0,adv.backpacknum());
        assertEquals(1,adv.itemnum());
        adv.useitem("heal",adv2);
        assertEquals(0,adv.backpacknum());
        assertEquals(1,adv.itemnum());
        assertEquals(701,adv2.gethitpoint());
        assertEquals(9,adv.getmana());
    }

    @Test
    public void setatkzero(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(1,adv.getatk());
        adv.setatkzero();
        assertEquals(0,adv.getatk());
    }

    @Test
    public void subatk(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(1,adv.getatk());
        adv.addatk(20);
        assertEquals(21,adv.getatk());
        adv.subatk(2);
        assertEquals(19,adv.getatk());
    }

    @Test
    public void subdef(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(0,adv.getdef());
        adv.adddef(20);
        assertEquals(20,adv.getdef());
        adv.subdef(2);
        assertEquals(18,adv.getdef());
    }
}