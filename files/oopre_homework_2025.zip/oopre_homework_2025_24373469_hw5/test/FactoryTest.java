import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FactoryTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void createBottle() {
    }

    @Test
    public void createSpell() {
    }

    @Test
    public void createEquipment() {
    }

    @Test
    public void createItem() {

    }

    @Test
    public void testCreate() {
        assertTrue(Factory.createBottle("HpBottle", "hp1", 50) instanceof HpBottle);
        assertTrue(Factory.createBottle("AtkBottle", "atk1", 50) instanceof AtkBottle);
        assertTrue(Factory.createBottle("DefBottle", "def1", 50) instanceof DefBottle);
        assertTrue(Factory.createBottle("ManaBottle", "mana1", 50) instanceof ManaBottle);
        assertNull(Factory.createBottle("UnknownBottle", "unknown1", 50));
    }

    @Test
    public void testSpell() {
        assertTrue(Factory.createSpell("HealSpell", "heal1", 5, 50) instanceof HealSpell);
        assertTrue(Factory.createSpell("AttackSpell", "attack1", 5, 50) instanceof AttackSpell);
        assertTrue(Factory.createSpell("UnknownSpell", "unknown1", 5, 50) instanceof Spell);
    }

    @Test
    public void testEquipment() {
        assertTrue(Factory.createEquipment("Sword", "sword1", 30) instanceof Sword);
        assertTrue(Factory.createEquipment("Magicbook", "book1", 25) instanceof Magicbook);
        assertTrue(Factory.createEquipment("Armour", "armour1", 20) instanceof Armour);
        assertTrue(Factory.createEquipment("UnknownEquipment", "unknown1", 10) instanceof Equipment);
    }

    @Test
    public void testItem() {
        // Test bottle creation through createItem
        assertTrue(Factory.createItem("HpBottle", "hp1", 50) instanceof Bottle);

        // Test equipment creation through createItem
        assertTrue(Factory.createItem("Sword", "sword1", 30) instanceof Equipment);
    }
}