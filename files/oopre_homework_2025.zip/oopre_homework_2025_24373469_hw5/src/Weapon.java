public class Weapon extends Equipment {

    public Weapon(String id,int ce) {
        super(id,ce);
    }

    @Override
    public String getTypeName() {
        return "Weapon";
    }

}
