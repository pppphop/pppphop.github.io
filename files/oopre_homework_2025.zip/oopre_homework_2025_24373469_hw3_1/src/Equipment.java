public class Equipment implements Item {

    private String id;

    public boolean use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0) {
            return true;
        }
        return false;
    }

    public Equipment(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getTypeName() {
        return "Equipment";
    }

    @Override
    public boolean useable() {
        return true;
    }
}
