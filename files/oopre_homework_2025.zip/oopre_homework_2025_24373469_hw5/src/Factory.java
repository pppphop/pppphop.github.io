public class Factory {
    public static Bottle createBottle(String type, String id, int effect) {
        switch (type) {
            case "HpBottle":
                return new HpBottle(id, effect);
            case "AtkBottle":
                return new AtkBottle(id, effect);
            case "DefBottle":
                return new DefBottle(id, effect);
            case "ManaBottle":
                return new ManaBottle(id, effect);
            default:
                return null;
        }
    }

    public static Spell createSpell(String type, String id, int cost, int power) {
        switch (type) {
            case "HealSpell":
                return new HealSpell(id,cost,power,type);
            case "AttackSpell":
                return new AttackSpell(id,cost,power,type);
            default: return new Spell(id, cost, power, type);
        }
    }

    public static Equipment createEquipment(String type, String id, int ce) {
        switch (type) {
            case "Sword":
                return new Sword(id,ce);
            case "Magicbook":
                return new Magicbook(id,ce);
            case "Armour":
                return new Armour(id,ce);
            default: return new Equipment(id,ce);
        }
    }

    public static Item createItem(String type, String id, int money) {
        Item item = createBottle(type, id, money);
        if (item == null) {
            return createEquipment(type, id, money);
        } else {
            return item;
        }
    }
}
