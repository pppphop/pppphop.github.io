import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HealSpellTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getId() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        assertEquals("heal",hs.getId());
    }

    @Test
    public void getManaCost() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        assertEquals(1,hs.getManaCost());
    }

    @Test
    public void getPower() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        assertEquals(350,hs.getPower());
    }

    @Test
    public void getTypeName() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        assertEquals("HealSpell",hs.getTypeName());
    }

    @Test
    public void use() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        Adventurer adv1 = new Adventurer("Alice");
        adv1.addspell(hs);
        assertEquals(1, adv1.spellnum());
        Adventurer adv2 = new Adventurer("Bob");
        hs.use(adv1,adv2);
        assertEquals(850,adv2.gethitpoint());
        assertEquals(1, adv1.spellnum());
        assertEquals(9, adv1.getmana());
        Spell as = new AttackSpell("Fire",2,2000,"AttackSpell");
        adv1.addspell(as);
        as.use(adv1,adv2);
        assertEquals(0,adv2.gethitpoint());
        assertEquals(1,adv2.checkdead());
        adv1.addspell(hs);
        hs.use(adv1,adv2);
        assertEquals(0,adv2.gethitpoint());
        assertEquals(1,adv2.checkdead());
    }

    @Test
    public void useable() {
        Spell hs = new HealSpell("heal",1,350,"HealSpell");
        assertTrue(hs.useable());
    }

    @Test
    public void testGetTypeName() {
    }

    @Test
    public void testUse() {
    }
}