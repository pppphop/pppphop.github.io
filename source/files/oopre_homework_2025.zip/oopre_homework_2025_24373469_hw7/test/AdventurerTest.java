import org.junit.Test;
import static org.junit.Assert.*;

public class AdventurerTest {
    private Adventurer adventurer;

    @org.junit.Before
    public void setUp() throws Exception {
        adventurer = new Adventurer("testAdv");
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    @Test
    public void testAdventurerCreation() {
        assertEquals("testAdv", adventurer.getId());
        assertEquals(500, adventurer.gethitpoint());
        assertEquals(1, adventurer.getatk());
        assertEquals(0, adventurer.getdef());
        assertEquals(10, adventurer.getmana());
        assertEquals(50, adventurer.getMoney());
        assertEquals(0, adventurer.checkdead());
    }

    @Test
    public void getId() {
        Adventurer adv=new Adventurer("2025");
        assertEquals("2025",adv.getId());
    }

    @Test
    public void addBottle() {
        Adventurer adv=new Adventurer("Alice");
        assertEquals(0,adv.bottlenum());

        Bottle bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        Bottle bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
    }

    @Test
    public void addEquipment() {
        Adventurer adv=new Adventurer("2025");
        Equipment equip1=new Equipment("equip1",0);
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        Equipment equip2=new Equipment("equip2",0);
        adv.addEquipment(equip2);
        assertEquals(2,adv.equipmentnum());
    }

    @Test
    public void testMoneyOperations() {
        adventurer.addMoney(100);
        assertEquals(150, adventurer.getMoney());

        boolean success = adventurer.subMoney(50);
        assertTrue(success);
        assertEquals(100, adventurer.getMoney());

        success = adventurer.subMoney(200);
        assertFalse(success);
        assertEquals(100, adventurer.getMoney());
    }

    @Test
    public void bottlenum() {
    }

    @Test
    public void equipmentnum() {
    }

    @Test
    public void testDeathStatus() {
        adventurer.setHitpointzero();
        assertEquals(1, adventurer.checkdead());
        assertEquals(0, adventurer.gethitpoint());
    }

    @Test
    public void testop() {
        adventurer.addhitpoint(100);
        assertEquals(600, adventurer.gethitpoint());

        adventurer.subhitpoint(50);
        assertEquals(550, adventurer.gethitpoint());

        adventurer.addatk(5);
        assertEquals(6, adventurer.getatk());

        adventurer.adddef(3);
        assertEquals(3, adventurer.getdef());

        adventurer.addmana(5);
        assertEquals(15, adventurer.getmana());
    }

    @org.junit.Test
    public void delBottle() {
        Adventurer adv=new Adventurer("Alice");
        assertEquals(0,adv.bottlenum());

        Bottle bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        Bottle bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
        adv.delBottle("bottle2");
        assertEquals(1,adv.bottlenum());
        adv.delBottle("bottle1");
        assertEquals(0,adv.bottlenum());
        bottle1=new Bottle("bottle1",1);
        adv.addBottle(bottle1);
        assertEquals(1,adv.bottlenum());
        bottle2=new Bottle("bottle2",2);
        adv.addBottle(bottle2);
        assertEquals(2,adv.bottlenum());
        adv.delBottle("bottle1");
        assertEquals(1,adv.bottlenum());
        adv.delBottle("bottle2");
        assertEquals(0,adv.bottlenum());
    }

    @org.junit.Test
    public void delEquipment() {
        Adventurer adv=new Adventurer("2025");
        Equipment equip1=new Equipment("equip1",0);
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        Equipment equip2=new Equipment("equip2",0);
        adv.addEquipment(equip2);
        assertEquals(2,adv.equipmentnum());
        adv.delEquipment("equip1");
        assertEquals(1,adv.equipmentnum());
        adv.delEquipment("equip2");
        assertEquals(0,adv.equipmentnum());
        adv.addEquipment(equip1);
        assertEquals(1,adv.equipmentnum());
        adv.delEquipment("equip1");
        assertEquals(0,adv.equipmentnum());
    }

    @Test
    public void additem(){
        Adventurer adv=new Adventurer("2025");
        Bottle bottle1=new HpBottle("HpBottle1",1);
        adv.addBottle(bottle1);
        assertEquals(0,adv.backpacknum());
        Equipment e=new Equipment("equip1",0);
        adv.addEquipment(e);
        adv.additem("equip1");
        assertEquals(1,adv.backpacknum());
        adv.additem("HpBottle1");
        assertEquals(2,adv.backpacknum());
        Spell sp = new HealSpell("heal",1,200,"HealSpell");
        adv.addspell(sp);
        assertEquals(2,adv.backpacknum());
        Bottle bottle2=new AtkBottle("AtkBottle1",2);
        adv.addBottle(bottle2);
        adv.additem("AtkBottle1");
        assertEquals(3,adv.backpacknum());
        adv.delitem("AtkBottle1");
        assertEquals(2,adv.backpacknum());
        adv.delitem("HpBottle1");
        assertEquals(1,adv.backpacknum());
        adv.delitem("equip1");
        assertEquals(0,adv.backpacknum());
    }

    @Test
    public void useitem(){
        Adventurer adv=new Adventurer("2025");
        Adventurer adv2=new Adventurer("2026");
        Bottle bottle1=new HpBottle("HpBottle1",1);
        adv.addBottle(bottle1);
        adv.additem("HpBottle1");
        adv.useitem("HpBottle1",adv2);
        assertEquals(0,adv.backpacknum());
        assertEquals(501,adv2.gethitpoint());
        Spell sp = new HealSpell("heal",1,200,"HealSpell");
        adv.addspell(sp);
        adv.additem("heal");
        assertEquals(0,adv.backpacknum());
        assertEquals(1,adv.itemnum());
        adv.useitem("heal",adv2);
        assertEquals(0,adv.backpacknum());
        assertEquals(1,adv.itemnum());
        assertEquals(701,adv2.gethitpoint());
        assertEquals(9,adv.getmana());
    }

    @Test
    public void setatkzero(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(1,adv.getatk());
        adv.setatkzero();
        assertEquals(0,adv.getatk());
    }

    @Test
    public void subatk(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(1,adv.getatk());
        adv.addatk(20);
        assertEquals(21,adv.getatk());
        adv.subatk(2);
        assertEquals(19,adv.getatk());
    }

    @Test
    public void subdef(){
        Adventurer adv=new Adventurer("2025");
        assertEquals(0,adv.getdef());
        adv.adddef(20);
        assertEquals(20,adv.getdef());
        adv.subdef(2);
        assertEquals(18,adv.getdef());
    }

    @Test
    public void testEffectsAndCESum() {
        Bottle bottle1 = new Bottle("bottle1", 50);
        Bottle bottle2 = new Bottle("bottle2", 75);
        adventurer.addBottle(bottle1);
        adventurer.addBottle(bottle2);

        Equipment equip1 = new Equipment("equip1", 20);
        Equipment equip2 = new Equipment("equip2", 30);
        adventurer.addEquipment(equip1);
        adventurer.addEquipment(equip2);

        assertEquals(125, adventurer.effectsum()); // 50 + 75
        assertEquals(50, adventurer.cesum()); // 20 + 30
    }

    @Test
    public void testequip() {
        Sword sword = new Sword("sword1", 15);
        Armour armour = new Armour("armour1", 10);

        adventurer.addEquipment(sword);
        adventurer.addEquipment(armour);
        adventurer.additem("sword1");
        adventurer.additem("armour1");

        assertEquals(16, adventurer.getFinalAtk()); // 1 + 15
        assertEquals(10, adventurer.getFinalDef()); // 0 + 10
    }

    @Test
    public void checkRemoveFirstBottle(){
        Bottle bottle1 = new HpBottle("bottle1", 50);
        Bottle bottle2 = new HpBottle("bottle2", 50);
        Bottle bottle3 = new HpBottle("bottle3", 50);
        Bottle bottle4 = new HpBottle("bottle4", 50);
        Bottle bottle5 = new HpBottle("bottle5", 50);
        Bottle bottle6 = new HpBottle("bottle6", 50);
        Bottle bottle7 = new HpBottle("bottle7", 50);
        Bottle bottle8 = new HpBottle("bottle8", 50);
        Bottle bottle9 = new HpBottle("bottle9", 50);
        Bottle bottle10 = new HpBottle("bottle10", 50);
        Bottle bottle11 = new HpBottle("bottle11", 50);
        Bottle bottle12 = new HpBottle("bottle12", 50);
        Bottle bottle13 = new HpBottle("bottle13", 50);
        adventurer.addBottle(bottle1);
        adventurer.addBottle(bottle2);
        adventurer.addBottle(bottle3);
        adventurer.addBottle(bottle4);
        adventurer.addBottle(bottle5);
        adventurer.addBottle(bottle6);
        adventurer.addBottle(bottle7);
        adventurer.addBottle(bottle8);
        adventurer.addBottle(bottle9);
        adventurer.addBottle(bottle10);
        adventurer.addBottle(bottle11);
        adventurer.addBottle(bottle12);
        adventurer.addBottle(bottle13);
        adventurer.additem(bottle1.getId());
        adventurer.additem(bottle2.getId());
        adventurer.additem(bottle3.getId());
        adventurer.additem(bottle4.getId());
        adventurer.additem(bottle5.getId());
        adventurer.additem(bottle6.getId());
        adventurer.additem(bottle7.getId());
        adventurer.additem(bottle8.getId());
        adventurer.additem(bottle9.getId());
        adventurer.additem(bottle10.getId());
        adventurer.additem(bottle11.getId());
        adventurer.additem(bottle12.getId());
        adventurer.additem(bottle13.getId());
        assertEquals(10,adventurer.backpacknum());
        assertEquals(bottle5,adventurer.findItem(bottle5.getId()));
        assertEquals(bottle6,adventurer.findUsableItem(bottle6.getId()));
    }

    @Test
    public void findSpell() {
        Spell spell1 = new HealSpell("spell1",1,100,"HealSpell");
        adventurer.addspell(spell1);
        assertNotNull(adventurer.findItem(spell1.getId()));
        assertNotNull(adventurer.findUsableItem(spell1.getId()));
    }
}