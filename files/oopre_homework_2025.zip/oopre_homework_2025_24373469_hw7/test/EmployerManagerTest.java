import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import static org.junit.Assert.*;

public class EmployerManagerTest {
    private Map<String, Adventurer> adventurers;
    private EmployerManager employerManager;
    @Before
    public void setUp() throws Exception {
        adventurers = new HashMap<>();
        adventurers.put("King", new Adventurer("King"));
        adventurers.put("Knight", new Adventurer("Knight"));
        adventurers.put("Archer", new Adventurer("Archer"));
        adventurers.put("Rogue", new Adventurer("Rogue"));
        employerManager = new EmployerManager(adventurers);
    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void addEmployment() {
        boolean result = employerManager.addEmployment("King", "Knight");
        assertTrue(result);
        assertTrue(employerManager.isSuperior("King", "Knight"));
    }

    @Test
    public void removeEmployment() {
    }

    @Test
    public void handleDeath() {
        // 建立复杂关系
        employerManager.addEmployment("King", "Knight");
        employerManager.addEmployment("Knight", "Archer");
        employerManager.addEmployment("King", "Rogue");

        // 验证初始状态
        assertTrue(employerManager.isSuperior("King", "Knight"));
        assertTrue(employerManager.isSuperior("Knight", "Archer"));
        assertTrue(employerManager.isSuperior("King", "Rogue"));

        // 处理 Knight 的死亡
        employerManager.handleDeath("Knight");

        // 验证死亡后的状态
        assertFalse(employerManager.isSuperior("King", "Knight"));
        assertFalse(employerManager.isSuperior("Knight", "Archer"));
        assertFalse(employerManager.isSuperior("King", "Archer")); // 间接关系也应移除
        assertTrue(employerManager.isSuperior("King", "Rogue")); // 无关关系应保持不变
    }

    @Test
    public void isSuperior() {
    }

    @Test
    public void isAlly() {
        assertTrue(employerManager.isAlly("King", "King"));
        assertFalse(employerManager.isAlly("King", "Rogue"));
    }

    @Test
    public void getAllSubordinates() {
    }

    @Test
    public void getDirectSubordinates() {
    }

    @Test
    public void checkInternalState() {
        // 测试复杂层级关系的内部状态
        employerManager.addEmployment("King", "Knight");
        employerManager.addEmployment("Knight", "Archer");
        employerManager.addEmployment("Archer", "Rogue");

        // 验证多层上级关系
        assertTrue(employerManager.isSuperior("King", "Archer"));
        assertTrue(employerManager.isSuperior("King", "Rogue"));
        assertTrue(employerManager.isSuperior("Knight", "Rogue"));

        // 验证直接下属
        Set<String> kingSubordinates = employerManager.getDirectSubordinates("King");
        assertEquals(1, kingSubordinates.size());
        assertTrue(kingSubordinates.contains("Knight"));

        Set<String> knightSubordinates = employerManager.getDirectSubordinates("Knight");
        assertEquals(1, knightSubordinates.size());
        assertTrue(knightSubordinates.contains("Archer"));

        // 验证所有下属
        Set<String> allKingSubordinates = employerManager.getAllSubordinates("King");
        assertEquals(3, allKingSubordinates.size());
        assertTrue(allKingSubordinates.contains("Knight"));
        assertTrue(allKingSubordinates.contains("Archer"));
        assertTrue(allKingSubordinates.contains("Rogue"));
    }

    @Test
    public void testRemoveEmploymentInternalState() {
        // 建立关系
        employerManager.addEmployment("King", "Knight");
        employerManager.addEmployment("King", "Archer");

        // 验证关系存在
        assertTrue(employerManager.isSuperior("King", "Knight"));
        assertTrue(employerManager.isSuperior("King", "Archer"));

        // 移除一个关系
        employerManager.removeEmployment("King", "Knight");

        // 验证关系已移除
        assertFalse(employerManager.isSuperior("King", "Knight"));
        assertTrue(employerManager.isSuperior("King", "Archer")); // 另一个关系应保持不变
    }
}