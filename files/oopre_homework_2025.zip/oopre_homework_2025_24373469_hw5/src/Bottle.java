public class Bottle implements Item {
    private String id;
    private int effect;

    public Bottle(String id,int effect) {
        this.id = id;
        this.effect = effect;
    }

    public boolean use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0) {
            user.delitem(this.id);
            user.delBottle(this.id);
            return true;
        }
        return false;
    }

    public void Item(){

    }

    public String getId() {
        return id;
    }

    public int getEffect() {
        return effect;
    }

    public String getName() {
        return "Bottle";
    }

    public String getTypeName() {
        return "Bottle";
    }

    public boolean useable() {
        return true;
    }
}
