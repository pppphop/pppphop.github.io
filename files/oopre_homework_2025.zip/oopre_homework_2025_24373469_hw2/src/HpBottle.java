public class HpBottle extends Bottle {

    public HpBottle(String id, int effect) {
        super(id, effect);
    }

    @Override
    public String getName() {
        return "HpBottle";
    }

    @Override
    public void use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0){
            target.addhitpoint(this.getEffect());
            user.delitem(this.getId());
            user.delBottle(this.getId());
        }
    }

    @Override
    public String getTypeName() {
        return "HpBottle";
    }

}
