import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class EquipmentTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void use() {
        Adventurer adv1= new Adventurer("1");
        Adventurer adv2= new Adventurer("2");
        Equipment e1= new Equipment("e1");
        adv1.addEquipment(e1);
        e1.use(adv1,adv2);
        assertEquals(1,adv1.equipmentnum());
    }

    @Test
    public void getId() {
        Equipment e=new Equipment("equip");
        assertEquals("equip",e.getId());
    }

    @Test
    public void getTypeName() {
        Equipment e=new Equipment("equip");
        assertEquals("Equipment",e.getTypeName());
    }

    @Test
    public void useable() {
        Equipment e=new Equipment("equip");
        assertTrue(e.useable());
    }
}