public class AttackSpell extends Spell {

    public AttackSpell(String id, int manaCost, int power, String type) {
        super(id, manaCost, power, type);
    }

    @Override
    public String getTypeName() {
        return "AttackSpell";
    }

    @Override
    public boolean use(Adventurer user, Adventurer target) {
        if (user.getmana() >= this.getManaCost() && target.checkdead() + user.checkdead() == 0) {
            user.submana(this.getManaCost());
            if (target.gethitpoint() >= this.getPower()) {
                target.subhitpoint(this.getPower());
            }
            else {
                target.setHitpointzero();
                user.addMoney(calculateReward(target));
            }
            return true;
        }
        return false;
    }

    private int calculateReward(Adventurer target) {
        int sum = 0;
        sum += target.getMoney();
        sum += target.effectsum();
        sum += target.cesum();
        return  sum;
    }
}
