import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class SpellTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getId() {
        Spell spell = new Spell("Fire",5,250,"HealSpell");
        assertEquals("Fire",spell.getId());
    }

    @Test
    public void getManaCost() {
        Spell spell = new Spell("Fire",5,250,"HealSpell");
        assertEquals(5,spell.getManaCost());
    }

    @Test
    public void getPower() {
        Spell spell = new Spell("Fire",5,250,"HealSpell");
        assertEquals(250,spell.getPower());
    }

    @Test
    public void getTypeName() {
        Spell spell = new Spell("Fire",5,250,"HealSpell");
        assertEquals("HealSpell",spell.getTypeName());
    }

    @Test
    public void use() {
        Adventurer adv1=new Adventurer("Alice");
        Adventurer adv2=new Adventurer("Bob");
        Spell sp=new Spell("Fire",5,250,"HealSpell");
        adv1.addspell(sp);
        sp.use(adv1,adv2);
        assertEquals(1,adv1.spellnum());
    }

    @Test
    public void useable() {
        Spell spell = new Spell("Fire",5,250,"HealSpell");
        assertTrue(spell.useable());
    }
}