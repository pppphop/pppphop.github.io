import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class MainTest {

    private static ArrayList<Adventurer> adventurers = new ArrayList<>();

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void addAdventurer() {
        //Main.addAdventurer("Alice");
        //assertEquals(1,Main.Adventurernum());
        //Main.clearAdventurers();
    }

    @Test
    public void addBottle() {
        /*Main.addAdventurer("Alice");
        String name1="Alice";
        String name2="bottle2";
        String name3="HpBottle";
        String name4="1";
        Main.addBottle(name1,name2,name3,name4);
        Adventurer adv = Main.getAdventurer("Alice");
        assertNotNull(adv);
        assertEquals(1,adv.bottlenum());
        Main.clearAdventurers();*/
    }

    @Test
    public void addEquipment() {
    }

    @Test
    public void lSpell() {
    }

    @Test
    public void removeitem() {
    }

    @Test
    public void takeitem() {
    }

    @Test
    public void useitem() {
    }
}