import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    private static  ArrayList<Adventurer> adventurers = new ArrayList<>();

    public static void main(String[] args) {
        ArrayList<ArrayList<String>> inputInfo = new ArrayList<>(); // 解析后的输入将会存进该容器中, 类似于c语言的二维数组
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine().trim()); // 读取行数
        for (int i = 0; i < n; i++) {
            String nextLine = scanner.nextLine(); // 读取本行指令
            String[] strings = nextLine.trim().split(" +"); // 按空格对行进行分割
            inputInfo.add(new ArrayList<>(Arrays.asList(strings))); // 将指令分割后的各个部分存进容器中
        }
        for (int i = 0; i < n; i++) {
            String name1;
            String name2;
            String name3;
            String name4;
            switch (inputInfo.get(i).get(0)) {
                case "aa":
                    addAdventurer(inputInfo.get(i).get(1));
                    break;
                case "ab":
                    name1 = inputInfo.get(i).get(1);
                    name2 = inputInfo.get(i).get(2);
                    name3 = inputInfo.get(i).get(3);
                    name4 = inputInfo.get(i).get(4);
                    addBottle(name1, name2, name3, name4);
                    break;
                case "ae":
                    addEquipment(inputInfo.get(i).get(1), inputInfo.get(i).get(2));
                    break;
                case "ls":
                    name1 = inputInfo.get(i).get(1);
                    name2 = inputInfo.get(i).get(2);
                    name3 = inputInfo.get(i).get(3);
                    name4 = inputInfo.get(i).get(4);
                    String name5 = inputInfo.get(i).get(5);
                    lSpell(name1, name2, name3, name4, name5);
                    break;
                case "ri":
                    removeitem(inputInfo.get(i).get(1),inputInfo.get(i).get(2));
                    break;
                case "ti":
                    takeitem(inputInfo.get(i).get(1),inputInfo.get(i).get(2));
                    break;
                case "use":
                    name1 = inputInfo.get(i).get(1);
                    name2 = inputInfo.get(i).get(2);
                    name3 = inputInfo.get(i).get(3);
                    useitem(name1,name2,name3);
                    break;
                default:
            }
        }
    }

    public static void addAdventurer(String name) {
        Adventurer advnew = new Adventurer(name);
        adventurers.add(advnew);
    }

    public static void addBottle(String name1,String name2, String name3, String name4) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name1)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                String idnow = name2;
                int effectnow = Integer.parseInt(name4);
                String type = name3;
                Bottle bot = null;
                if (type.equals("HpBottle")) {
                    bot = new HpBottle(idnow, effectnow);
                }
                else if (type.equals("AtkBottle")) {
                    bot = new AtkBottle(idnow, effectnow);
                }
                else if (type.equals("DefBottle")) {
                    bot = new DefBottle(idnow, effectnow);
                }
                else if (type.equals("ManaBottle")) {
                    bot = new ManaBottle(idnow, effectnow);
                }
                else {
                    bot = new Bottle(idnow, effectnow);
                }
                adv.addBottle(bot);
                break;
            }
        }
    }

    public static void addEquipment(String name1,String name2) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name1)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                Equipment equip = new Equipment(name2);
                adv.addEquipment(equip);
                break;
            }
        }
    }

    public static void lSpell(String name, String name2, String name3, String name4, String name5) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                String speId = name2;
                String type = name3;
                int manaCost = Integer.parseInt(name4);
                int power = Integer.parseInt(name5);
                Spell spell;
                if (type.equals("HealSpell")) {
                    spell = new HealSpell(speId, manaCost, power, type);
                }
                else if (type.equals("AttackSpell")) {
                    spell = new AttackSpell(speId, manaCost, power, type);
                }
                else {
                    spell = new Spell(speId, manaCost, power, type);
                }
                adv.addspell(spell);
                break;
            }
        }
    }

    public static void removeitem(String name1,String name2) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name1)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                String itemid = name2;
                String nowdeltype = adv.delitem(itemid);
                System.out.println(nowdeltype);
            }
        }
    }

    public static void takeitem(String name1,String name2) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name1)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                String type = adv.additem(name2);
                System.out.println(type);
                break;
            }
        }
    }

    public static void useitem(String name1,String name2,String name3) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(name1)) {
                if (adv.checkdead() == 1) {
                    System.out.println(adv.getId() + " is dead!");
                    break;
                }
                String usable = name2;
                String targetid = name3;
                Adventurer target = null;
                for (Adventurer adv2 : adventurers) {
                    if (adv2.getId().equals(targetid)) {
                        target = adv2;
                        break;
                    }
                }
                if (target.checkdead() == 1) {
                    System.out.println(target.getId() + " is dead!");
                    break;
                }
                boolean suc = adv.useitem(usable, target);
                if (!suc) {
                    System.out.println(adv.getId() + " failed to use " + usable);
                } else {
                    int a = target.gethitpoint();
                    int b = target.getatk();
                    int c = target.getdef();
                    int d = target.getmana();
                    System.out.println(target.getId() + " " + a + " " + b + " " + c + " " + d);
                }
                break;
            }
        }
    }

    public static Adventurer getAdventurer(String id) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(id)) {
                return adv;
            }
        }
        return null;
    }

    public static int Adventurernum() {
        return adventurers.size();
    }

    public static void clearAdventurers() {
        adventurers.clear();
    }
}