public class Parser {
    private Lexer lexer;
    private EmployerManager employerManager;

    public Parser(Lexer lexer,EmployerManager employerManager) {
        this.lexer = lexer;
        this.employerManager = employerManager;
    }

    public void parseAdventurer(String bossId) {
        String adventurerId = lexer.peek();
        if (adventurerId != null) {
            lexer.next();
        }
        if (bossId != null) {
            employerManager.addEmployment(bossId, adventurerId);
        }
        if (lexer.peek() != null && lexer.peek().equals("(")) {
            lexer.next();
            parseAdventurerList(adventurerId);
            if (lexer.peek() != null && lexer.peek().equals(")")) {
                lexer.next();
            }
        }
    }

    private void parseAdventurerList(String bossId) {
        parseAdventurer(bossId);

        while (lexer.peek() != null && lexer.peek().equals(",")) {
            lexer.next(); // 消耗 ','
            parseAdventurer(bossId);
        }
    }

    public void parse() {
        parseAdventurer(null); // 从根节点开始解析，没有上级
    }
}
