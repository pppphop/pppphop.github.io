import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class EmployerManager {
    private Map<String, Adventurer> adventurers;
    private Map<String, Set<String>> subAdv = new HashMap<>();      //上级->下属ID集合的映射
    private Map<String, String> bossAdv = new HashMap<>();          //下属->上级ID的映射

    public EmployerManager(Map<String, Adventurer> adventurers) {
        this.adventurers = adventurers;
    }

    public boolean addEmployment(String bossId, String employeeId) {
        if (!adventurers.containsKey(bossId) || !adventurers.containsKey(employeeId)) {
            return false;
        }
        Adventurer employer = adventurers.get(bossId);
        Adventurer employee = adventurers.get(employeeId);
        if (employer.checkdead() == 1 || employee.checkdead() == 1) {
            return false;
        }

        subAdv.computeIfAbsent(bossId, k -> new HashSet<>()).add(employeeId);
        bossAdv.put(employeeId,bossId);

        return true;
    }

    public void removeEmployment(String bossId, String employeeId) {
        bossAdv.remove(employeeId);
        if (subAdv.containsKey(bossId)) {
            subAdv.get(bossId).remove(employeeId);
        }
    }

    public void handleDeath(String deadAdventurerId) {
        String bossId = bossAdv.remove(deadAdventurerId);
        if (bossId != null && subAdv.containsKey(bossId)) {
            subAdv.get(bossId).remove(deadAdventurerId);
        }
        Set<String> sub = subAdv.remove(deadAdventurerId);
        if (sub != null) {
            for (String adv : sub) {
                bossAdv.remove(adv);
            }
        }
    }

    public boolean isSuperior(String bid, String aid) {
        if (aid.equals(bid)) {
            return false;
        }
        String current = aid;
        while (bossAdv.containsKey(current)) {
            current = bossAdv.get(current);
            if (current.equals(bid)) {
                return true;
            }
        }
        return false;
    }

    public boolean isAlly(String aid, String bid) {
        if (aid.equals(bid)) {
            return true;
        }
        return isSuperior(aid, bid) || isSuperior(bid, aid);
    }

    public Set<String> getAllSubordinates(String adventurerId) {
        Set<String> allSubordinates = new HashSet<>();

        if (subAdv.containsKey(adventurerId)) {
            for (String directSubordinate : subAdv.get(adventurerId)) {
                allSubordinates.add(directSubordinate);
                allSubordinates.addAll(getAllSubordinates(directSubordinate));
            }
        }

        return allSubordinates;
    }

    public Set<String> getDirectSubordinates(String adventurerId) {
        Set<String> subordinates = subAdv.get(adventurerId);
        return subordinates != null ? new HashSet<>(subordinates) : new HashSet<>();
    }
}
