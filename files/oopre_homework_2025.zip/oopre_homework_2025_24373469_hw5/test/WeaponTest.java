import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class WeaponTest {

    Weapon wp;
    @Before
    public void setUp() throws Exception {
        String id = "114514";
        int ce = 0;
        wp = new Weapon(id,ce);
    }

    @Test
    public void getTypeName() {
        assertEquals("Weapon",wp.getTypeName());
    }
}