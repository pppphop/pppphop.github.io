public class Magicbook extends Weapon {
    public Magicbook(String id,int ce) {
        super(id,ce);
    }

    @Override
    public String getTypeName() {
        return "Magicbook";
    }
}
