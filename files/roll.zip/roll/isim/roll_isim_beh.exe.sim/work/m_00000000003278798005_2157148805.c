/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Xilinx/roll/roll.v";
static int ng1[] = {0, 0};
static int ng2[] = {8, 0};
static int ng3[] = {1, 0};
static int ng4[] = {4, 0};
static int ng5[] = {7, 0};
static int ng6[] = {2, 0};
static int ng7[] = {3, 0};
static int ng8[] = {5, 0};
static int ng9[] = {6, 0};



static void Always_27_0(char *t0)
{
    char t6[8];
    char t13[8];
    char t22[8];
    char t24[8];
    char t26[8];
    char t29[8];
    char t30[8];
    char t64[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t23;
    char *t25;
    char *t27;
    char *t28;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    int t42;
    char *t43;
    unsigned int t44;
    int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    int t49;
    int t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t65;
    char *t66;

LAB0:    t1 = (t0 + 1812U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng0);
    t2 = (t0 + 2152);
    *((int *)t2) = 1;
    t3 = (t0 + 1840);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(27, ng0);

LAB5:    xsi_set_current_line(28, ng0);
    xsi_set_current_line(28, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1196);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB6:    t2 = (t0 + 1196);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 920);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 920);
    t7 = (t5 + 44U);
    t14 = *((char **)t7);
    t15 = (t0 + 920);
    t16 = (t15 + 40U);
    t17 = *((char **)t16);
    t18 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t6, 8, t4, t14, t17, 2, 1, t18, 32, 1);
    t19 = (t0 + 1012);
    t20 = (t0 + 1012);
    t21 = (t20 + 44U);
    t23 = *((char **)t21);
    t25 = (t0 + 1012);
    t27 = (t25 + 40U);
    t28 = *((char **)t27);
    t31 = ((char*)((ng1)));
    xsi_vlog_generic_convert_array_indices(t13, t22, t23, t28, 2, 1, t31, 32, 1);
    t32 = (t13 + 4);
    t8 = *((unsigned int *)t32);
    t42 = (!(t8));
    t33 = (t22 + 4);
    t9 = *((unsigned int *)t33);
    t45 = (!(t9));
    t46 = (t42 && t45);
    if (t46 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(32, ng0);
    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1196);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB14:    t2 = (t0 + 1196);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB15;

LAB16:    goto LAB2;

LAB7:    xsi_set_current_line(28, ng0);

LAB9:    xsi_set_current_line(29, ng0);
    t14 = (t0 + 600U);
    t15 = *((char **)t14);
    t14 = (t0 + 576U);
    t16 = (t14 + 44U);
    t17 = *((char **)t16);
    t18 = (t0 + 1196);
    t19 = (t18 + 36U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng3)));
    memset(t22, 0, 8);
    xsi_vlog_signed_add(t22, 32, t20, 32, t21, 32);
    t23 = ((char*)((ng4)));
    memset(t24, 0, 8);
    xsi_vlog_signed_multiply(t24, 32, t22, 32, t23, 32);
    t25 = ((char*)((ng3)));
    memset(t26, 0, 8);
    xsi_vlog_signed_minus(t26, 32, t24, 32, t25, 32);
    t27 = ((char*)((ng4)));
    xsi_vlog_get_indexed_partselect(t13, 8, t15, ((int*)(t17)), 2, t26, 32, 1, t27, 32, 1, 0);
    t28 = (t0 + 920);
    t31 = (t0 + 920);
    t32 = (t31 + 44U);
    t33 = *((char **)t32);
    t34 = (t0 + 920);
    t35 = (t34 + 40U);
    t36 = *((char **)t35);
    t37 = (t0 + 1196);
    t38 = (t37 + 36U);
    t39 = *((char **)t38);
    xsi_vlog_generic_convert_array_indices(t29, t30, t33, t36, 2, 1, t39, 32, 1);
    t40 = (t29 + 4);
    t41 = *((unsigned int *)t40);
    t42 = (!(t41));
    t43 = (t30 + 4);
    t44 = *((unsigned int *)t43);
    t45 = (!(t44));
    t46 = (t42 && t45);
    if (t46 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 1196);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 1196);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB6;

LAB10:    t47 = *((unsigned int *)t29);
    t48 = *((unsigned int *)t30);
    t49 = (t47 - t48);
    t50 = (t49 + 1);
    xsi_vlogvar_assign_value(t28, t13, 0, *((unsigned int *)t30), t50);
    goto LAB11;

LAB12:    t10 = *((unsigned int *)t13);
    t11 = *((unsigned int *)t22);
    t49 = (t10 - t11);
    t50 = (t49 + 1);
    xsi_vlogvar_assign_value(t19, t6, 0, *((unsigned int *)t22), t50);
    goto LAB13;

LAB15:    xsi_set_current_line(32, ng0);

LAB17:    xsi_set_current_line(33, ng0);
    t14 = (t0 + 1012);
    t15 = (t14 + 36U);
    t16 = *((char **)t15);
    t17 = (t0 + 1012);
    t18 = (t17 + 44U);
    t19 = *((char **)t18);
    t20 = (t0 + 1012);
    t21 = (t20 + 40U);
    t23 = *((char **)t21);
    t25 = (t0 + 1196);
    t27 = (t25 + 36U);
    t28 = *((char **)t27);
    xsi_vlog_generic_get_array_select_value(t13, 8, t16, t19, t23, 2, 1, t28, 32, 1);
    t31 = (t0 + 920);
    t32 = (t31 + 36U);
    t33 = *((char **)t32);
    t34 = (t0 + 920);
    t35 = (t34 + 44U);
    t36 = *((char **)t35);
    t37 = (t0 + 920);
    t38 = (t37 + 40U);
    t39 = *((char **)t38);
    t40 = (t0 + 1196);
    t43 = (t40 + 36U);
    t51 = *((char **)t43);
    t52 = ((char*)((ng3)));
    memset(t24, 0, 8);
    xsi_vlog_signed_add(t24, 32, t51, 32, t52, 32);
    xsi_vlog_generic_get_array_select_value(t22, 8, t33, t36, t39, 2, 1, t24, 32, 1);
    memset(t26, 0, 8);
    xsi_vlog_unsigned_add(t26, 8, t13, 8, t22, 8);
    t53 = (t0 + 1012);
    t54 = (t0 + 1012);
    t55 = (t54 + 44U);
    t56 = *((char **)t55);
    t57 = (t0 + 1012);
    t58 = (t57 + 40U);
    t59 = *((char **)t58);
    t60 = (t0 + 1196);
    t61 = (t60 + 36U);
    t62 = *((char **)t61);
    t63 = ((char*)((ng3)));
    memset(t64, 0, 8);
    xsi_vlog_signed_add(t64, 32, t62, 32, t63, 32);
    xsi_vlog_generic_convert_array_indices(t29, t30, t56, t59, 2, 1, t64, 32, 1);
    t65 = (t29 + 4);
    t41 = *((unsigned int *)t65);
    t42 = (!(t41));
    t66 = (t30 + 4);
    t44 = *((unsigned int *)t66);
    t45 = (!(t44));
    t46 = (t42 && t45);
    if (t46 == 1)
        goto LAB18;

LAB19:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1196);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 1196);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB14;

LAB18:    t47 = *((unsigned int *)t29);
    t48 = *((unsigned int *)t30);
    t49 = (t47 - t48);
    t50 = (t49 + 1);
    xsi_vlogvar_assign_value(t53, t26, 0, *((unsigned int *)t30), t50);
    goto LAB19;

}

static void Cont_36_1(char *t0)
{
    char t3[16];
    char t6[8];
    char t17[8];
    char t28[8];
    char t39[8];
    char t50[8];
    char t61[8];
    char t72[8];
    char t83[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;

LAB0:    t1 = (t0 + 1956U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1012);
    t4 = (t2 + 36U);
    t5 = *((char **)t4);
    t7 = (t0 + 1012);
    t8 = (t7 + 44U);
    t9 = *((char **)t8);
    t10 = (t0 + 1012);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    t13 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t6, 8, t5, t9, t12, 2, 1, t13, 32, 1);
    t14 = (t0 + 1012);
    t15 = (t14 + 36U);
    t16 = *((char **)t15);
    t18 = (t0 + 1012);
    t19 = (t18 + 44U);
    t20 = *((char **)t19);
    t21 = (t0 + 1012);
    t22 = (t21 + 40U);
    t23 = *((char **)t22);
    t24 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t17, 8, t16, t20, t23, 2, 1, t24, 32, 1);
    t25 = (t0 + 1012);
    t26 = (t25 + 36U);
    t27 = *((char **)t26);
    t29 = (t0 + 1012);
    t30 = (t29 + 44U);
    t31 = *((char **)t30);
    t32 = (t0 + 1012);
    t33 = (t32 + 40U);
    t34 = *((char **)t33);
    t35 = ((char*)((ng6)));
    xsi_vlog_generic_get_array_select_value(t28, 8, t27, t31, t34, 2, 1, t35, 32, 1);
    t36 = (t0 + 1012);
    t37 = (t36 + 36U);
    t38 = *((char **)t37);
    t40 = (t0 + 1012);
    t41 = (t40 + 44U);
    t42 = *((char **)t41);
    t43 = (t0 + 1012);
    t44 = (t43 + 40U);
    t45 = *((char **)t44);
    t46 = ((char*)((ng7)));
    xsi_vlog_generic_get_array_select_value(t39, 8, t38, t42, t45, 2, 1, t46, 32, 1);
    t47 = (t0 + 1012);
    t48 = (t47 + 36U);
    t49 = *((char **)t48);
    t51 = (t0 + 1012);
    t52 = (t51 + 44U);
    t53 = *((char **)t52);
    t54 = (t0 + 1012);
    t55 = (t54 + 40U);
    t56 = *((char **)t55);
    t57 = ((char*)((ng4)));
    xsi_vlog_generic_get_array_select_value(t50, 8, t49, t53, t56, 2, 1, t57, 32, 1);
    t58 = (t0 + 1012);
    t59 = (t58 + 36U);
    t60 = *((char **)t59);
    t62 = (t0 + 1012);
    t63 = (t62 + 44U);
    t64 = *((char **)t63);
    t65 = (t0 + 1012);
    t66 = (t65 + 40U);
    t67 = *((char **)t66);
    t68 = ((char*)((ng8)));
    xsi_vlog_generic_get_array_select_value(t61, 8, t60, t64, t67, 2, 1, t68, 32, 1);
    t69 = (t0 + 1012);
    t70 = (t69 + 36U);
    t71 = *((char **)t70);
    t73 = (t0 + 1012);
    t74 = (t73 + 44U);
    t75 = *((char **)t74);
    t76 = (t0 + 1012);
    t77 = (t76 + 40U);
    t78 = *((char **)t77);
    t79 = ((char*)((ng9)));
    xsi_vlog_generic_get_array_select_value(t72, 8, t71, t75, t78, 2, 1, t79, 32, 1);
    t80 = (t0 + 1012);
    t81 = (t80 + 36U);
    t82 = *((char **)t81);
    t84 = (t0 + 1012);
    t85 = (t84 + 44U);
    t86 = *((char **)t85);
    t87 = (t0 + 1012);
    t88 = (t87 + 40U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng5)));
    xsi_vlog_generic_get_array_select_value(t83, 8, t82, t86, t89, 2, 1, t90, 32, 1);
    xsi_vlogtype_concat(t3, 64, 64, 8U, t83, 8, t72, 8, t61, 8, t50, 8, t39, 8, t28, 8, t17, 8, t6, 8);
    t91 = (t0 + 2204);
    t92 = (t91 + 32U);
    t93 = *((char **)t92);
    t94 = (t93 + 40U);
    t95 = *((char **)t94);
    xsi_vlog_bit_copy(t95, 0, t3, 0, 32);
    xsi_driver_vfirst_trans(t91, 0, 31);
    t96 = (t0 + 2160);
    *((int *)t96) = 1;

LAB1:    return;
}


extern void work_m_00000000003278798005_2157148805_init()
{
	static char *pe[] = {(void *)Always_27_0,(void *)Cont_36_1};
	xsi_register_didat("work_m_00000000003278798005_2157148805", "isim/roll_isim_beh.exe.sim/work/m_00000000003278798005_2157148805.didat");
	xsi_register_executes(pe);
}
