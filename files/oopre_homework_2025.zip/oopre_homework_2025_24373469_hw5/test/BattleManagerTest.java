import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import java.util.ArrayList;

public class BattleManagerTest {
    private Adventurer atker;
    private ArrayList<Adventurer> targets;

    @Before
    public void setUp() throws Exception {
        atker = new Adventurer("attacker1");
        targets = new ArrayList<>();
        targets.add(new Adventurer("target1"));
        targets.add(new Adventurer("target2"));
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void fight() {
    }

    @Test
    public void testDeadAttacker(){
        atker.setHitpointzero();
        BattleManager battle = new BattleManager(atker, targets);
        assertFalse(battle.fight());
    }

    @Test
    public void testMagicbooktrue() {
        Magicbook magicbook = new Magicbook("magic1", 25);
        atker.addEquipment(magicbook);
        atker.additem("magic1");

        BattleManager battle = new BattleManager(atker, targets);
        boolean result = battle.fight();

        assertTrue(result);
        assertEquals(5, atker.getmana());
        assertEquals(474,targets.get(0).gethitpoint());
    }

    public void testMagicbookfalse() {
        Magicbook magicbook = new Magicbook("magic1", 100);
        atker.addEquipment(magicbook);
        atker.additem("magic1");
        atker.submana(5); // Reduce mana to 5

        BattleManager battle = new BattleManager(atker, targets);
        boolean result = battle.fight();

        assertFalse(result);
        assertEquals(500,targets.get(0).gethitpoint());
        assertEquals(5, atker.getmana());
    }

    @Test
    public void testSword() {
        Sword sword = new Sword("sword1", 10);
        atker.addEquipment(sword);
        atker.additem("sword1");

        // Give targets some defense
        for (Adventurer target : targets) {
            target.adddef(2);
        }

        BattleManager battle = new BattleManager(atker, targets);
        boolean result = battle.fight();

        assertTrue(result);
        assertEquals(491,targets.get(0).gethitpoint());
    }

    @Test
    public void testSwordfail() {
        Sword sword = new Sword("sword1", 5);
        atker.addEquipment(sword);
        atker.additem("sword1");

        for (Adventurer target : targets) {
            target.adddef(20);
        }

        BattleManager battle = new BattleManager(atker, targets);
        boolean result = battle.fight();

        assertFalse(result);
        assertEquals(500,targets.get(0).gethitpoint());
    }

    @Test
    public void testKillsTarget() {
        Sword sword = new Sword("sword1", 500);
        atker.addEquipment(sword);
        atker.additem("sword1");

        // Make target have low HP
        Adventurer weakTarget = new Adventurer("weak");
        weakTarget.subhitpoint(400); // Only 100 HP left
        ArrayList<Adventurer> singleTarget = new ArrayList<>();
        singleTarget.add(weakTarget);

        BattleManager battle = new BattleManager(atker, singleTarget);
        boolean result = battle.fight();

        assertTrue(result);
        assertEquals(0, weakTarget.gethitpoint());
        assertEquals(100,atker.getMoney());
    }
}