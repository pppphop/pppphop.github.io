import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.HashMap;

public class GameManager {
    private HashMap<String, Adventurer> adventurers = new HashMap<>();
    private Shop shop = new Shop();

    public void start() {
        ArrayList<ArrayList<String>> inputInfo = new ArrayList<>(); // 解析后的输入将会存进该容器中, 类似于c语言的二维数组
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < n; i++) {
            String nextLine = scanner.nextLine();
            String[] strings = nextLine.trim().split(" +");
            inputInfo.add(new ArrayList<>(Arrays.asList(strings)));
            //processCmd(strings);
        }
        for (int i = 0; i < n; i++) {
            ArrayList<String> stringList = inputInfo.get(i);
            String[] strings = stringList.toArray(new String[0]);
            processCmd(strings);
        }
    }

    public void processCmd(String[] strings) {
        String cmd = strings[0];
        switch (strings[0]) {
            case "aa":
                addAdventurer(strings[1]);
                break;
            case "ab":
                addBottle(strings[1], strings[2], strings[3], strings[4]);
                break;
            case "ae":
                addEquipment(strings[1], strings[2], strings[3], strings[4]);
                break;
            case "ls":
                learnSpell(strings[1], strings[2], strings[3], strings[4], strings[5]);
                break;
            case "ri":
                removeItem(strings[1], strings[2]);
                break;
            case "ti":
                takeItem(strings[1], strings[2]);
                break;
            case "use":
                useItem(strings[1], strings[2], strings[3]);
                break;
            case "bi":
                buyItem(strings[1], strings[2], strings[3]);
                break;
            case "fight":
                fight(strings);
                break;
            default:
        }
    }

    public void addAdventurer(String name) {
        adventurers.put(name,new Adventurer(name));
    }

    public void addBottle(String advId, String bottleId, String type, String effectStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int effectnow = Integer.parseInt(effectStr);
        Bottle bot = Factory.createBottle(type, bottleId, effectnow);
        if (bot != null) {
            adv.addBottle(bot);
        }
    }

    public Adventurer getAdventurer(String advId) {
        return adventurers.get(advId);
    }

    public void addEquipment(String advId, String equipmentId,String type,String ceStr) {
        Adventurer adv = getAdventurer(advId);
        int ce = Integer.parseInt(ceStr);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        Equipment equip = Factory.createEquipment(type, equipmentId, ce);
        adv.addEquipment(equip);
    }

    public void learnSpell(String advId,String speId,String type,String manaStr,String powStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int manaCost = Integer.parseInt(manaStr);
        int power = Integer.parseInt(powStr);
        Spell spell = Factory.createSpell(type, speId, manaCost, power);;
        if (spell != null) {
            adv.addspell(spell);
        }
    }

    public void removeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String nowdeltype = adv.delitem(itemId);
        System.out.println(nowdeltype);
    }

    public void takeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String type = adv.additem(itemId);
        System.out.println(type);
    }

    public void useItem(String advId,String usableId,String targetId) {
        Adventurer adv = getAdventurer(advId);
        Adventurer target = getAdventurer(targetId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        if (target.checkdead() == 1) {
            System.out.println(target.getId() + " is dead!");
            return;
        }
        boolean suc = adv.useitem(usableId, target);
        if (!suc) {
            System.out.println(adv.getId() + " fail to use " + usableId);
        } else {
            int a = target.gethitpoint();
            int b = target.getatk();
            int c = target.getdef();
            int d = target.getmana();
            System.out.println(target.getId() + " " + a + " " + b + " " + c + " " + d);
        }
    }

    public int adventurernum() {
        return adventurers.size();
    }

    public void buyItem(String advId,String itemId,String type) {
        Adventurer adv = getAdventurer(advId);
        if (adv == null || adv.checkdead() == 1) {
            System.out.println(advId + " is dead!");
            return;
        }
        int usemoney = Math.min(adv.getMoney(),100);
        Item item = shop.buy(type,itemId,usemoney);
        if (item != null) {
            adv.subMoney(usemoney);
            if (item instanceof Bottle) {
                adv.addBottle((Bottle)item);
            }
            else if (item instanceof Equipment) {
                adv.addEquipment((Equipment) item);
            }
        }
        System.out.println(adv.getMoney());
    }

    public void fight(String[] strings) {
        String atkerId = strings[1];
        int k = Integer.parseInt(strings[2]);
        Adventurer atker = getAdventurer(atkerId);
        if (atker == null || atker.checkdead() == 1) {
            System.out.println(atkerId + " is dead!");
            return;
        }
        ArrayList<Adventurer> targets = new ArrayList<>();
        for (int i = 1;i <= k;i++) {
            String targetId = strings[i + 2];
            Adventurer target = getAdventurer(targetId);
            if (target != null && target.checkdead() == 0) {
                targets.add(target);
            }
        }
        BattleManager battle = new BattleManager(atker,targets);
        boolean success = battle.fight();
        if (!success) {
            System.out.println("Adventurer " + atkerId + " defeated");
        }
        else {
            for (Adventurer adv : targets) {
                System.out.printf("%d ",adv.gethitpoint());
            }
            System.out.print("\n");
        }
    }
}
