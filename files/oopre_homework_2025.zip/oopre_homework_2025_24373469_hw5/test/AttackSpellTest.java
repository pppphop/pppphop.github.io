import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AttackSpellTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getId() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        assertEquals("Fire",as.getId());
    }

    @Test
    public void getManaCost() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        assertEquals(2,as.getManaCost());
    }

    @Test
    public void getPower() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        assertEquals(200,as.getPower());
    }

    @Test
    public void getTypeName() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        assertEquals("AttackSpell",as.getTypeName());
    }

    @Test
    public void use() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        Adventurer adv1 = new Adventurer("Alice");
        adv1.addspell(as);
        assertEquals(1, adv1.spellnum());
        Adventurer adv2 = new Adventurer("Bob");
        as.use(adv1,adv2);
        assertEquals(300,adv2.gethitpoint());
        assertEquals(1, adv1.spellnum());
        assertEquals(8,adv1.getmana());
        Spell as2 =new AttackSpell("Lightening",8,605,"AttackSpell");
        adv1.addspell(as2);
        as2.use(adv1,adv2);
        assertEquals(0,adv2.gethitpoint());
        assertEquals(1,adv2.checkdead());
        assertEquals(0,adv1.getmana());
        Adventurer adv3 = new Adventurer("Carter");
        as2.use(adv1,adv3);
        assertEquals(500,adv3.gethitpoint());
        assertEquals(0,adv1.getmana());
    }

    @Test
    public void useable() {
        Spell as = new AttackSpell("Fire",2,200,"AttackSpell");
        assertTrue(as.useable());
    }

    @Test
    public void testGetTypeName() {
    }

    @Test
    public void testUse() {
    }
}