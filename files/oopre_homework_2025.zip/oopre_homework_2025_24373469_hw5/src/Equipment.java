public class Equipment implements Item {

    private String id;
    private int ce;

    public boolean use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0) {
            return true;
        }
        return false;
    }

    public Equipment(String id,int ce) {
        this.id = id;
        this.ce = ce;
    }

    public String getId() {
        return id;
    }

    public String getTypeName() {
        return "Equipment";
    }

    public int getce() {
        return ce;
    }

    @Override
    public boolean useable() {
        return true;
    }
}
