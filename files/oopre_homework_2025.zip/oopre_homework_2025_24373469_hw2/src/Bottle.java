public class Bottle implements Item {
    private String id;
    private int effect;

    public Bottle(String id,int effect) {
        this.id = id;
        this.effect = effect;
    }

    public void use(Adventurer user, Adventurer target) {
        user.delitem(this.id);
        user.delBottle(this.id);
    }

    public void Item(){

    }

    public String getId() {
        return id;
    }

    public int getEffect() {
        return effect;
    }

    public String getName() {
        return "Bottle";
    }

    public String getTypeName() {
        return "Bottle";
    }

    public boolean useable() {
        return true;
    }
}
