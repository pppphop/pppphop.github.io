public class Equipment implements Item {

    private String id;

    public void use(Adventurer user, Adventurer target){

    }

    public Equipment(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getTypeName() {
        return "Equipment";
    }

    @Override
    public boolean useable() {
        return true;
    }
}
