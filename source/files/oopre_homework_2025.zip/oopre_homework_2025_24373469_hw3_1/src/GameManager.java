import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;

public class GameManager {
    private ArrayList<Adventurer> adventurers = new ArrayList<>();

    public void start() {
        ArrayList<ArrayList<String>> inputInfo = new ArrayList<>(); // 解析后的输入将会存进该容器中, 类似于c语言的二维数组
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < n; i++) {
            String nextLine = scanner.nextLine();
            String[] strings = nextLine.trim().split(" +");
            inputInfo.add(new ArrayList<>(Arrays.asList(strings)));
            //processCmd(strings);
        }
        for (int i = 0; i < n; i++) {
            ArrayList<String> stringList = inputInfo.get(i);
            String[] strings = stringList.toArray(new String[0]);
            processCmd(strings);
        }
    }

    public void processCmd(String[] strings) {
        String cmd = strings[0];
        switch (strings[0]) {
            case "aa":
                addAdventurer(strings[1]);
                break;
            case "ab":
                addBottle(strings[1], strings[2], strings[3], strings[4]);
                break;
            case "ae":
                addEquipment(strings[1], strings[2]);
                break;
            case "ls":
                learnSpell(strings[1], strings[2], strings[3], strings[4], strings[5]);
                break;
            case "ri":
                removeItem(strings[1], strings[2]);
                break;
            case "ti":
                takeItem(strings[1], strings[2]);
                break;
            case "use":
                useItem(strings[1], strings[2], strings[3]);
                break;
            default:
        }
    }

    public void addAdventurer(String name) {
        adventurers.add(new Adventurer(name));
    }

    public void addBottle(String advId, String bottleId, String type, String effectStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int effectnow = Integer.parseInt(effectStr);
        Bottle bot = null;
        switch (type) {
            case "HpBottle":
                bot = new HpBottle(bottleId, effectnow);
                break;
            case "AtkBottle":
                bot = new AtkBottle(bottleId, effectnow);
                break;
            case "DefBottle":
                bot = new DefBottle(bottleId, effectnow);
                break;
            case "ManaBottle":
                bot = new ManaBottle(bottleId, effectnow);
                break;
            default:
                bot = new Bottle(bottleId, effectnow);
                break;
        }
        adv.addBottle(bot);
    }

    public Adventurer getAdventurer(String advId) {
        for (Adventurer adv : adventurers) {
            if (adv.getId().equals(advId)) {
                return adv;
            }
        }
        return null;
    }

    public void addEquipment(String advId, String equipmentId) {
        Adventurer  adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        Equipment equip = new Equipment(equipmentId);
        adv.addEquipment(equip);
    }

    public void learnSpell(String advId,String speId,String type,String manaStr,String powStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int manaCost = Integer.parseInt(manaStr);
        int power = Integer.parseInt(powStr);
        Spell spell;
        if (type.equals("HealSpell")) {
            spell = new HealSpell(speId, manaCost, power, type);
        }
        else if (type.equals("AttackSpell")) {
            spell = new AttackSpell(speId, manaCost, power, type);
        }
        else {
            spell = new Spell(speId, manaCost, power, type);
        }
        adv.addspell(spell);
    }

    public void removeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String nowdeltype = adv.delitem(itemId);
        System.out.println(nowdeltype);
    }

    public void takeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String type = adv.additem(itemId);
        System.out.println(type);
    }

    public void useItem(String advId,String usableId,String targetId) {
        Adventurer adv = getAdventurer(advId);
        Adventurer target = getAdventurer(targetId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        if (target.checkdead() == 1) {
            System.out.println(target.getId() + " is dead!");
            return;
        }
        boolean suc = adv.useitem(usableId, target);
        if (!suc) {
            System.out.println(adv.getId() + " fail to use " + usableId);
        } else {
            int a = target.gethitpoint();
            int b = target.getatk();
            int c = target.getdef();
            int d = target.getmana();
            System.out.println(target.getId() + " " + a + " " + b + " " + c + " " + d);
        }
    }

    public int adventurernum() {
        return adventurers.size();
    }
}
