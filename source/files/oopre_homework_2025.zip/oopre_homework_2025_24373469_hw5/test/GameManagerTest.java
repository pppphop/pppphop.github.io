import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class GameManagerTest {

    private GameManager gameManager=new GameManager();
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void start() {
    }

    @Test
    public void processCmd(){
        String[] cmd={"aa","Alice"};
        gameManager.processCmd(cmd);
        assertEquals(1,gameManager.adventurernum());
        String[] addBottleCmd={"ab","Alice","bottle1","HpBottle","100"};
        gameManager.processCmd(addBottleCmd);
        Adventurer adv=gameManager.getAdventurer(addBottleCmd[1]);
        assertEquals(1,adv.bottlenum());
        String[] takeItemCmd = {"ti", "Alice", "bottle1"};
        gameManager.processCmd(takeItemCmd);
        assertEquals(1,adv.itemnum());
        String[] addEquipmentCmd = {"ae", "Alice", "equipment1","Sword","0"};
        gameManager.processCmd(addEquipmentCmd);
        assertEquals(1,adv.equipmentnum());
        String[] takeItemCmd2 = {"ti", "Alice", "equipment1","Armour","0"};
        gameManager.processCmd(takeItemCmd2);
        assertEquals(2,adv.itemnum());
        String[] addBobcmd={"aa","Bob"};
        gameManager.processCmd(addBobcmd);
        Adventurer adv2=gameManager.getAdventurer(addBobcmd[1]);
        assertEquals(2,gameManager.adventurernum());
        String[] useItemCmd = {"use", "Alice", "bottle1", "Bob"};
        gameManager.processCmd(useItemCmd);
        assertEquals(1,adv.itemnum());
        assertEquals(0,adv.bottlenum());
        assertEquals(600,adv2.gethitpoint());
        String[] learnSpellCmd = {"ls", "Alice", "spell1", "AttackSpell", "5", "50"};
        gameManager.processCmd(learnSpellCmd);
        assertEquals(1,adv.spellnum());
        String[] usespell = {"use", "Alice", "spell1", "Bob"};
        gameManager.processCmd(usespell);
        assertEquals(1,adv.spellnum());
        assertEquals(550,adv2.gethitpoint());
        String[] removeItemCmd={"ri","Alice","equipment1"};
        gameManager.processCmd(removeItemCmd);
        assertEquals(0,adv.backpacknum());
        String[] addBottleCmd2={"ab","Alice","bottle2","AtkBottle","100"};
        gameManager.processCmd(addBottleCmd2);
        String[] addBottleCmd3={"ab","Alice","bottle3","DefBottle","100"};
        gameManager.processCmd(addBottleCmd3);
        String[] addBottleCmd4={"ab","Alice","bottle4","ManaBottle","100"};
        gameManager.processCmd(addBottleCmd4);
        String[] takeItemCmd3 = {"ti", "Alice", "bottle2"};
        gameManager.processCmd(takeItemCmd3);
        String[] takeItemCmd4 = {"ti", "Alice", "bottle3"};
        gameManager.processCmd(takeItemCmd4);
        String[] takeItemCmd5 = {"ti", "Alice", "bottle4"};
        gameManager.processCmd(takeItemCmd5);
        assertEquals(3,adv.backpacknum());
        String[] removeItemCmd2={"ri","Alice","bottle3"};
        gameManager.processCmd(removeItemCmd2);
        assertEquals(2,adv.backpacknum());
        String[] useItemCmd2 = {"use", "Alice", "bottle2", "Bob"};
        gameManager.processCmd(useItemCmd2);
        assertEquals(101,adv2.getatk());
        String[] useItemCmd3 = {"use", "Alice", "bottle4", "Alice"};
        gameManager.processCmd(useItemCmd3);
        assertEquals(105,adv.getmana());
        String[] learnSpellCmd2 = {"ls", "Alice", "spell2", "HealSpell", "5", "50"};
        gameManager.processCmd(learnSpellCmd2);
        assertEquals(2,adv.spellnum());
        String[] usespell2 = {"use", "Alice", "spell2", "Bob"};
        gameManager.processCmd(usespell2);
        String[] learnSpellCmd3 = {"ls", "Alice", "kill", "AttackSpell", "5", "5000"};
        gameManager.processCmd(learnSpellCmd3);
        assertEquals(3,adv.spellnum());
        String[] kill = {"use", "Alice", "kill", "Bob"};
        gameManager.processCmd(kill);
        assertEquals(1,adv2.checkdead());
        String[] kill2 = {"use", "Alice", "kill", "Bob"};
        gameManager.processCmd(kill2);
        assertEquals(1,adv2.checkdead());
    }

    @Test
    public void testBuyItem() {
        gameManager.processCmd(new String[]{"aa", "adv1"});
        gameManager.processCmd(new String[]{"bi", "adv1", "bottle1", "HpBottle"});

        Adventurer adv = gameManager.getAdventurer("adv1");
        assertEquals(0, adv.getMoney());
        assertEquals(1,adv.bottlenum());
    }

    @Test
    public void testFight() {
        gameManager.processCmd(new String[]{"aa", "attacker"});
        gameManager.processCmd(new String[]{"aa", "target1"});
        gameManager.processCmd(new String[]{"aa", "target2"});

        // Give attacker a weapon
        gameManager.processCmd(new String[]{"ae", "attacker", "sword1", "Sword", "50"});
        gameManager.processCmd(new String[]{"ti", "attacker", "sword1"});

        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});

        Adventurer target1 = gameManager.getAdventurer("target1");
        Adventurer target2 = gameManager.getAdventurer("target2");

        // Both targets should have taken damage
        assertTrue(target1.gethitpoint() < 500 || target2.gethitpoint() < 500);
        assertEquals(449,target1.gethitpoint());
        assertEquals(449,target2.gethitpoint());

        gameManager.processCmd(new String[]{"ae", "target1", "armour1", "Armour", "150"});
        gameManager.processCmd(new String[]{"ae", "target2", "armour2", "Armour", "50"});
        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});
        assertEquals(398,target1.gethitpoint());
        assertEquals(398,target2.gethitpoint());
        gameManager.processCmd(new String[]{"ti", "target2", "armour2"});
        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});
        assertEquals(397,target1.gethitpoint());
        assertEquals(397,target2.gethitpoint());
        gameManager.processCmd(new String[]{"ti", "target1", "armour1"});

        assertEquals(397,target1.gethitpoint());
        assertEquals(397,target2.gethitpoint());
    }
}