public class AtkBottle extends Bottle {

    public AtkBottle(String id, int effect) {
        super(id, effect);
    }

    @Override
    public String getName() {
        return "AtkBottle";
    }

    @Override
    public boolean use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0) {
            target.addatk(this.getEffect());
            user.delitem(this.getId());
            user.delBottle(this.getId());
            return true;
        }
        return false;
    }

    @Override
    public String getTypeName() {
        return "AtkBottle";
    }
}
