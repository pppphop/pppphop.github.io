import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class BottleTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void use() {
        Adventurer adv1=new Adventurer("Alice");
        Adventurer adv2=new Adventurer("Bob");
        Bottle b=new Bottle("blank",0);
        adv1.addBottle(b);
        b.use(adv1,adv2);
        assertEquals(0,adv1.bottlenum());
    }

    @Test
    public void item() {
         Bottle b=new Bottle("blank",0);
         b.Item();
    }

    @Test
    public void getId() {
        Bottle b = new Bottle("1", 1);
        assertEquals("1", b.getId());
    }

    @Test
    public void getEffect() {
        Bottle b=new Bottle("bottle",1);
        assertEquals(1,b.getEffect());
    }

    @Test
    public void getName() {
        Bottle b = new Bottle("bottle", 1);
        assertEquals("Bottle", b.getName());
    }

    @Test
    public void getTypeName() {
        Bottle b = new Bottle("bottle", 1);
        assertEquals("Bottle", b.getTypeName());
    }

    @Test
    public void useable() {
        Bottle b = new Bottle("bottle", 1);
        assertEquals(true,b.useable());
    }
}