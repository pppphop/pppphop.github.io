import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AtkBottleTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void use() {
        Adventurer adv=new Adventurer("Alice");
        Bottle b=new AtkBottle("bottle1", 1);
        Adventurer adv2=new Adventurer("Bob");
        adv.addBottle(b);
        assertEquals(1,adv.bottlenum());
        b.use(adv,adv2);
        assertEquals(2,adv2.getatk());
        assertEquals(0,adv.bottlenum());
        assertEquals(0,adv.backpacknum());
    }

    @Test
    public void item() {
    }

    @Test
    public void getId() {
        Bottle b=new AtkBottle("bottle1", 1);
        assertEquals("bottle1",b.getId());
    }

    @Test
    public void getEffect() {
        Bottle b=new AtkBottle("bottle1", 1);
        assertEquals(1,b.getEffect());
    }

    @Test
    public void getName() {
        Bottle b=new AtkBottle("bottle1", 1);
        assertEquals("AtkBottle",b.getName());
    }

    @Test
    public void getTypeName() {
        Bottle b=new AtkBottle("bottle1", 1);
        assertEquals("AtkBottle",b.getTypeName());
    }

    @Test
    public void useable() {
        Bottle b=new AtkBottle("bottle1", 1);
        assertTrue(b.useable());
    }

    @Test
    public void testGetName() {
    }

    @Test
    public void testUse() {
    }

    @Test
    public void testGetTypeName() {
    }
}