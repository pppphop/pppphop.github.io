import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LexerTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void next() {
    }

    @Test
    public void peek() {
    }

    @Test
    public void testSimpleIdentifier() {
        Lexer lexer = new Lexer("King");
        assertEquals("King", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testIdentifierWithUnderscore() {
        Lexer lexer = new Lexer("King_1");
        assertEquals("King_1", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testParentheses() {
        Lexer lexer = new Lexer("King(Knight)");
        assertEquals("King", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("Knight", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testCommaSeparated() {
        Lexer lexer = new Lexer("King,Knight,Archer");
        assertEquals("King", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("Knight", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("Archer", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testComplexStructure() {
        Lexer lexer = new Lexer("King(Knight(Archer),Rogue)");
        assertEquals("King", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("Knight", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("Archer", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("Rogue", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testNestedStructure() {
        Lexer lexer = new Lexer("A(B(C,D(E)),F)");
        assertEquals("A", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("B", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("C", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("D", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("E", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("F", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testWhitespaceHandling() {
        Lexer lexer = new Lexer("  King  (  Knight  ,  Archer  )  ");
        assertEquals("King", lexer.peek());
        lexer.next();
        assertEquals("(", lexer.peek());
        lexer.next();
        assertEquals("Knight", lexer.peek());
        lexer.next();
        assertEquals(",", lexer.peek());
        lexer.next();
        assertEquals("Archer", lexer.peek());
        lexer.next();
        assertEquals(")", lexer.peek());
        lexer.next();
        assertNull(lexer.peek());
    }

    @Test
    public void testEmptyInput() {
        Lexer lexer = new Lexer("");
        assertNull(lexer.peek());
    }
}