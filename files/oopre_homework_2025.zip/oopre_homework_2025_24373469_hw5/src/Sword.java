public class Sword extends Weapon {
    public Sword(String id,int ce) {
        super(id,ce);
    }

    @Override
    public String getTypeName() {
        return "Sword";
    }
}
