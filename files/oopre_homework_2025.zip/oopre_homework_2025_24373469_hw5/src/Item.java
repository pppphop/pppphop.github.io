interface Item {
    String getId();

    String getTypeName();

    boolean useable();

    boolean use(Adventurer user, Adventurer target);
}
