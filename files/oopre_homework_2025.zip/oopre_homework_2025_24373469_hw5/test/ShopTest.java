import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ShopTest {
    Shop shop;

    @Before
    public void setUp() throws Exception {
        shop = new Shop();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void buy() {
    }

    @Test
    public void testBuyItem() {
        Item bottle = shop.buy("HpBottle", "hp1", 100);
        assertNotNull(bottle);
        assertTrue(bottle instanceof Bottle);
        assertEquals(100,((Bottle) bottle).getEffect());

        Item equipment = shop.buy("Sword", "sword1", 100);
        assertNotNull(equipment);
        assertTrue(equipment instanceof Equipment);
        assertEquals(100,((Equipment) equipment).getce());

        Item cheapItem = shop.buy("HpBottle", "hp2", 50);
        assertNotNull(cheapItem);
    }
}