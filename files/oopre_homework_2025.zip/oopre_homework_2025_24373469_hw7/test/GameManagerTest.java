import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.*;

public class GameManagerTest {

    private GameManager gameManager=new GameManager();
    private  EmployerManager employerManager;
    private Map<String, Adventurer> adventurers;
    @Before
    public void setUp() throws Exception {
        employerManager = new EmployerManager(adventurers);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void start() {
    }

    @Test
    public void processCmd(){
        String[] cmd={"aa","Alice"};
        gameManager.processCmd(cmd);
        assertEquals(1,gameManager.adventurernum());
        String[] addBottleCmd={"ab","Alice","bottle1","HpBottle","100"};
        gameManager.processCmd(addBottleCmd);
        Adventurer adv=gameManager.getAdventurer(addBottleCmd[1]);
        assertEquals(1,adv.bottlenum());
        String[] takeItemCmd = {"ti", "Alice", "bottle1"};
        gameManager.processCmd(takeItemCmd);
        assertEquals(1,adv.itemnum());
        String[] addEquipmentCmd = {"ae", "Alice", "equipment1","Sword","0"};
        gameManager.processCmd(addEquipmentCmd);
        assertEquals(1,adv.equipmentnum());
        String[] takeItemCmd2 = {"ti", "Alice", "equipment1","Armour","0"};
        gameManager.processCmd(takeItemCmd2);
        assertEquals(2,adv.itemnum());
        String[] addBobcmd={"aa","Bob"};
        gameManager.processCmd(addBobcmd);
        Adventurer adv2=gameManager.getAdventurer(addBobcmd[1]);
        assertEquals(2,gameManager.adventurernum());
        String[] addRelationCmd ={"ar","Alice","Bob"};
        gameManager.processCmd(addRelationCmd);
        String[] useItemCmd = {"use", "Alice", "bottle1", "Bob"};
        gameManager.processCmd(useItemCmd);
        assertEquals(1,adv.itemnum());
        assertEquals(0,adv.bottlenum());
        assertEquals(600,adv2.gethitpoint());
        String[] removeRelationCmd ={"rr","Alice","Bob"};
        gameManager.processCmd(removeRelationCmd);
        String[] learnSpellCmd = {"ls", "Alice", "spell1", "AttackSpell", "5", "50"};
        gameManager.processCmd(learnSpellCmd);
        assertEquals(1,adv.spellnum());
        String[] usespell = {"use", "Alice", "spell1", "Bob"};
        gameManager.processCmd(usespell);
        assertEquals(1,adv.spellnum());
        assertEquals(550,adv2.gethitpoint());
        gameManager.processCmd(addRelationCmd);
        String[] removeItemCmd={"ri","Alice","equipment1"};
        gameManager.processCmd(removeItemCmd);
        assertEquals(0,adv.backpacknum());
        String[] addBottleCmd2={"ab","Alice","bottle2","AtkBottle","100"};
        gameManager.processCmd(addBottleCmd2);
        String[] addBottleCmd3={"ab","Alice","bottle3","DefBottle","100"};
        gameManager.processCmd(addBottleCmd3);
        String[] addBottleCmd4={"ab","Alice","bottle4","ManaBottle","100"};
        gameManager.processCmd(addBottleCmd4);
        String[] takeItemCmd3 = {"ti", "Alice", "bottle2"};
        gameManager.processCmd(takeItemCmd3);
        String[] takeItemCmd4 = {"ti", "Alice", "bottle3"};
        gameManager.processCmd(takeItemCmd4);
        String[] takeItemCmd5 = {"ti", "Alice", "bottle4"};
        gameManager.processCmd(takeItemCmd5);
        assertEquals(3,adv.backpacknum());
        String[] removeItemCmd2={"ri","Alice","bottle3"};
        gameManager.processCmd(removeItemCmd2);
        assertEquals(2,adv.backpacknum());
        String[] useItemCmd2 = {"use", "Alice", "bottle2", "Bob"};
        gameManager.processCmd(useItemCmd2);
        assertEquals(101,adv2.getatk());
        String[] useItemCmd3 = {"use", "Alice", "bottle4", "Alice"};
        gameManager.processCmd(useItemCmd3);
        assertEquals(105,adv.getmana());
        String[] learnSpellCmd2 = {"ls", "Alice", "spell2", "HealSpell", "5", "50"};
        gameManager.processCmd(learnSpellCmd2);
        assertEquals(2,adv.spellnum());
        String[] usespell2 = {"use", "Alice", "spell2", "Bob"};
        gameManager.processCmd(usespell2);
        String[] learnSpellCmd3 = {"ls", "Alice", "kill", "AttackSpell", "5", "5000"};
        gameManager.processCmd(learnSpellCmd3);
        assertEquals(3,adv.spellnum());
        String[] kill = {"use", "Alice", "kill", "Bob"};
        gameManager.processCmd(kill);
        assertEquals(1,adv2.checkdead());
        gameManager.processCmd(removeRelationCmd);
        String[] kill2 = {"use", "Alice", "kill", "Bob"};
        gameManager.processCmd(kill2);
        assertEquals(1,adv2.checkdead());
    }

    @Test
    public void testBuyItem() {
        gameManager.processCmd(new String[]{"aa", "adv1"});
        gameManager.processCmd(new String[]{"bi", "adv1", "bottle1", "HpBottle"});

        Adventurer adv = gameManager.getAdventurer("adv1");
        assertEquals(0, adv.getMoney());
        assertEquals(1,adv.bottlenum());
    }

    @Test
    public void testFight() {
        gameManager.processCmd(new String[]{"aa", "attacker"});
        gameManager.processCmd(new String[]{"aa", "target1"});
        gameManager.processCmd(new String[]{"aa", "target2"});

        // Give attacker a weapon
        gameManager.processCmd(new String[]{"ae", "attacker", "sword1", "Sword", "50"});
        gameManager.processCmd(new String[]{"ti", "attacker", "sword1"});

        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});

        Adventurer target1 = gameManager.getAdventurer("target1");
        Adventurer target2 = gameManager.getAdventurer("target2");

        // Both targets should have taken damage
        assertTrue(target1.gethitpoint() < 500 || target2.gethitpoint() < 500);
        assertEquals(449,target1.gethitpoint());
        assertEquals(449,target2.gethitpoint());

        gameManager.processCmd(new String[]{"ae", "target1", "armour1", "Armour", "150"});
        gameManager.processCmd(new String[]{"ae", "target2", "armour2", "Armour", "50"});
        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});
        assertEquals(398,target1.gethitpoint());
        assertEquals(398,target2.gethitpoint());
        gameManager.processCmd(new String[]{"ti", "target2", "armour2"});
        gameManager.processCmd(new String[]{"fight", "attacker", "2", "target1", "target2"});
        assertEquals(397,target1.gethitpoint());
        assertEquals(397,target2.gethitpoint());
        gameManager.processCmd(new String[]{"ti", "target1", "armour1"});

        assertEquals(397,target1.gethitpoint());
        assertEquals(397,target2.gethitpoint());
    }

    @Test
    public void testHeal() {
        gameManager.processCmd(new String[]{"aa", "attacker"});
        gameManager.processCmd(new String[]{"aa", "target1"});
        gameManager.processCmd(new String[]{"aa", "target2"});
        String[] addRelationCmd ={"ar", "target1","target2"};
        gameManager.processCmd(addRelationCmd);
        gameManager.processCmd(new String[]{"ae", "attacker", "sword1", "Sword", "251"});
        gameManager.processCmd(new String[]{"ti", "attacker", "sword1"});
        gameManager.processCmd(new String[]{"ls", "target2", "spell1", "HealSpell", "5", "50"});
        String[] attackCmd ={"fight", "attacker","1","target1"};
        gameManager.processCmd(attackCmd);
        assertEquals(298, gameManager.getAdventurer("target1").gethitpoint());
        assertEquals(5, gameManager.getAdventurer("target2").getmana());
        String[] attackCmd2 ={"fight", "attacker","2","target1","target2"};
        gameManager.getAdventurer("attacker").addmana(114514);
        gameManager.processCmd(new String[]{"ae", "attacker", "magicbook1", "Magicbook", "50"});
        gameManager.processCmd(addRelationCmd);
        gameManager.processCmd(new String[]{"ti", "attacker", "magicbook1"});
        gameManager.processCmd(attackCmd2);
        assertEquals(247, gameManager.getAdventurer("target1").gethitpoint());
        gameManager.getAdventurer("attacker").addmana(114514);
        String[] attackCmd3 ={"fight", "attacker","1","target2"};
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd3);
        gameManager.processCmd(attackCmd2);
        assertEquals(196, gameManager.getAdventurer("target1").gethitpoint());
        gameManager.processCmd(new String[]{"aa", "target3"});
        String[] addRelationCmd2 ={"ar", "target1","target3"};
        gameManager.processCmd(addRelationCmd2);
        String[] addBottleCmd ={"ab","attacker","atk1","AtkBottle","49"};
        gameManager.processCmd(addBottleCmd);
        String[] takeBottleCmd ={"ti","attacker","atk1"};
        gameManager.processCmd(takeBottleCmd);
        String[] useBottleCmd = {"use","attacker","atk1","attacker"};
        gameManager.processCmd(useBottleCmd);
        gameManager.processCmd(attackCmd);
        assertEquals(96, gameManager.getAdventurer("target1").gethitpoint());
    }

    @Test
    public void testLoadRelation() {
        // 创建冒险者
        gameManager.processCmd(new String[]{"aa", "King"});
        gameManager.processCmd(new String[]{"aa", "Knight"});
        gameManager.processCmd(new String[]{"aa", "Archer"});
        gameManager.processCmd(new String[]{"aa", "Rogue"});
        gameManager.processCmd(new String[]{"aa", "Mage"});

        // 测试简单的 lr 指令
        String[] lrCmd1 = {"lr", "King(Knight)"};
        gameManager.processCmd(lrCmd1);

        // 验证雇佣关系 - 通过战斗测试（下属不能攻击上级）
        String[] fightCmd1 = {"fight", "Knight", "1", "King"};
        gameManager.processCmd(fightCmd1);
        // 应该输出 "That's my boss!" 且 King 的 HP 不变
        assertEquals(500, gameManager.getAdventurer("King").gethitpoint());

        // 测试复杂的 lr 指令
        String[] lrCmd2 = {"lr", "King(Knight(Archer),", "Rogue)"};
        gameManager.processCmd(lrCmd2);

        // 验证多层雇佣关系
        String[] fightCmd2 = {"fight", "Archer", "1", "King"};
        gameManager.processCmd(fightCmd2);
        // Archer 是 Knight 的下属，Knight 是 King 的下属，所以 Archer 不能攻击 King
        assertEquals(500, gameManager.getAdventurer("King").gethitpoint());

        String[] fightCmd3 = {"fight", "Archer", "1", "Rogue"};
        gameManager.processCmd(fightCmd3);
        // Archer 和 Rogue 都是 King 的下属，可以互相攻击
        assertTrue(gameManager.getAdventurer("Rogue").gethitpoint() < 500);

        // 测试更复杂的 lr 指令
        String[] lrCmd3 = {"lr", "King(Knight(Archer),", "Rogue,", "Mage)"};
        gameManager.processCmd(lrCmd3);

        // 验证 Mage 也被雇佣
        String[] fightCmd4 = {"fight", "Mage", "1", "King"};
        gameManager.processCmd(fightCmd4);
        assertEquals(500, gameManager.getAdventurer("King").gethitpoint());
    }

}