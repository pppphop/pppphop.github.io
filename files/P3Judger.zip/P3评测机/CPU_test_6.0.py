import re
import random
import os
import subprocess
import time
import filecmp


class MIPSCPUEvaluator:
    def __init__(self):
        # 配置路径 - 请根据你的实际情况修改这些路径
        self.mars_path = r"E:\pp\CO\mars.jar"
        self.my_cpu_path = r"E:\pp\CO\P3.circ"
        self.ref_cpu_path = r"E:\pp\CO\P3-wrong.circ"
        self.logisim_path = r"E:\pp\CO\logisim-win-2.7.1.exe"

        # 临时文件
        self.asm_file = "test_code.asm"
        self.machine_code_file = "machine_code.txt"
        self.my_output = "my_cpu_output.txt"
        self.ref_output = "ref_cpu_output.txt"

        # 支持的指令集
        self.r_type_ops = ['add', 'sub']
        self.i_type_ops = ['ori', 'lw', 'sw', 'beq', 'lui']  # lui是I型指令
        self.other_ops = ['nop']

        # 寄存器池 (避免使用$0和特殊寄存器)
        self.registers = [f"{i}" for i in range(1, 28)]

        # 地址限制
        self.max_pc = 0x6000  # PC最大地址
        self.max_dm = 0x2FFF  # DM最大地址
        self.current_pc = 0  # 当前PC位置

    def generate_mips_code(self, num_instructions, test_id):
        """
        生成随机的MIPS汇编代码，考虑地址限制
        """
        # 使用测试ID和时间作为随机种子，确保每次测试生成不同的代码
        random.seed(time.time() + test_id)

        instructions = []
        labels = {}  # 用于beq跳转的标签
        data_segment = []  # 数据段

        # 初始化当前PC（假设从0开始）
        self.current_pc = 0

        # 生成一些标签用于beq跳转，确保在PC范围内
        label_count = max(1, num_instructions // 10)
        for i in range(label_count):
            # 标签位置在当前PC范围内
            label_pos = random.randint(0, min(num_instructions - 1, (self.max_pc - self.current_pc) // 4))
            labels[f"label_{i}"] = label_pos

        # 添加数据段（在代码之前）
        data_size = min(32, num_instructions // 3)  # 数据大小限制
        for i in range(data_size):
            data_value = random.randint(0, 0xFFFFFFFF)
            data_segment.append(f"data_{i}: .word {data_value}")

        # 添加数据段声明
        if data_segment:
            instructions.append(".data")
            instructions.extend(data_segment)
            instructions.append("")  # 空行分隔

        # 添加代码段
        instructions.append(".text")

        # 初始化一些寄存器，避免未定义行为
        instructions.append("ori $1, $0, 0")  # 初始化$1为0
        instructions.append("ori $2, $0, 0")  # 初始化$2为0

        for i in range(num_instructions):
            # 更新当前PC（每条指令4字节）
            self.current_pc = (i + 2) * 4  # 加上初始化的2条指令

            # 随机决定是否在当前指令前插入标签
            for label_name, label_pos in labels.items():
                if label_pos == i:
                    instructions.append(f"{label_name}:")

            instr_type = random.choice(['r_type', 'i_type', 'other'])

            if instr_type == 'r_type':
                # R-type指令: add, sub
                op = random.choice(self.r_type_ops)
                rd, rs, rt = random.sample(self.registers, 3)
                instructions.append(f"{op} ${rd}, ${rs}, ${rt}")

            elif instr_type == 'i_type':
                # I-type指令: ori, lw, sw, beq, lui
                op = random.choice(self.i_type_ops)

                if op == 'lui':
                    # lui指令: lui rt, immediate
                    rt = random.choice(self.registers)
                    imm = random.randint(0, 65535)
                    instructions.append(f"{op} ${rt}, {imm}")
                elif op == 'beq':
                    # beq需要跳转标签，确保在PC范围内
                    rs, rt = random.sample(self.registers, 2)
                    if labels:
                        # 只选择在当前指令之前的标签，避免向前跳转太远
                        available_labels = {k: v for k, v in labels.items() if v < i}
                        if available_labels:
                            target_label = random.choice(list(available_labels.keys()))
                            instructions.append(f"{op} ${rs}, ${rt}, {target_label}")
                        else:
                            # 如果没有合适的标签，使用nop
                            instructions.append("nop")
                    else:
                        # 如果没有标签，生成一个相对跳转，限制范围
                        max_offset = min(127, (self.max_pc - self.current_pc) // 4 - 1)
                        if max_offset > 0:
                            offset = random.randint(1, max_offset)
                            instructions.append(f"{op} ${rs}, ${rt}, {offset}")
                        else:
                            instructions.append("nop")

                elif op in ['lw', 'sw']:
                    # 内存访问指令，确保在DM范围内
                    rs, rt = random.sample(self.registers, 2)
                    # 使用小偏移量，避免需要多条指令
                    max_offset = min(124, self.max_dm) & 0xFFFC  # 确保是4的倍数且不超过范围
                    if max_offset >= 4:
                        offset = random.randint(0, max_offset // 4) * 4
                        instructions.append(f"{op} ${rt}, {offset}(${rs})")
                    else:
                        # 如果偏移量太小，使用ori替代
                        imm = random.randint(0, 65535)
                        instructions.append(f"ori ${rt}, ${rs}, {imm}")
                else:
                    # ori指令
                    rs, rt = random.sample(self.registers, 2)
                    imm = random.randint(0, 65535)
                    instructions.append(f"{op} ${rt}, ${rs}, {imm}")

            else:
                # 其他指令: nop
                instructions.append("nop")

            # 检查PC是否超出范围
            if self.current_pc > self.max_pc - 8:  # 留出空间给结束指令
                print(f"  ! PC接近上限，提前结束指令生成")
                break

        # 在代码末尾添加停机指令 - 使用更可靠的停机方式
        #instructions.append("end_loop:")
        #instructions.append("ori $1, $0, 1")  # 设置$1=1
        #instructions.append("beq $1, $0, end_loop")  # 条件永远不成立，继续执行
        #instructions.append("j end_loop")  # 无条件跳转到循环开始

        return "\n".join(instructions)

    def generate_machine_code(self, asm_code):
        """
        使用Mars将汇编代码转换为机器码
        """
        # 写入汇编文件
        with open(self.asm_file, 'w') as f:
            f.write(asm_code)

        # 调用Mars生成机器码
        cmd = [
            'java', '-jar', self.mars_path,
            self.asm_file,
            'nc', 'mc', 'CompactDataAtZero', 'a',
            'dump', '.text', 'HexText', self.machine_code_file
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                print(f"Mars执行错误: {result.stderr}")
                return False

            # 检查机器码文件是否生成
            if not os.path.exists(self.machine_code_file):
                print("机器码文件未生成")
                return False

            # 读取并验证机器码
            with open(self.machine_code_file, 'r') as f:
                machine_code = f.read().strip()

            if not machine_code:
                print("机器码为空")
                return False

            # 显示机器码信息用于调试
            lines = machine_code.split('\n')
            print(f"  生成的机器码行数: {len(lines)}")
            if lines:
                print(f"  前5条机器码: {lines[:5]}")

            return True

        except subprocess.TimeoutExpired:
            print("Mars执行超时")
            return False
        except Exception as e:
            print(f"Mars执行异常: {e}")
            return False

    def inject_machine_code_to_circuit(self, circuit_path, machine_code):
        """
        将机器码注入到Logisim电路文件的ROM中
        针对你的Logisim文件格式进行优化
        """
        try:
            # 读取电路文件
            with open(circuit_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 查找IM电路中的ROM组件
            # 使用更精确的匹配模式
            im_circuit_pattern = r'<circuit name="IM">(.*?)</circuit>'
            im_match = re.search(im_circuit_pattern, content, re.DOTALL)

            if not im_match:
                print(f"  错误: 未找到IM电路")
                return False

            im_content = im_match.group(0)

            # 在IM电路中查找ROM的contents
            rom_patterns = [
                # 精确匹配ROM的contents
                r'(addr/data: 12 32\n).*?(</a>)'
                r'(<a name="contents">addr/data: 12 32\s*\n)(.*?)(\s*</a>)',
                r'(addr/data: 12 32\s*\n)(.*?)(\s*</a>)',
                # 更宽松的匹配
                r'(<a name="contents">.*?12 32\s*\n)(.*?)(\s*</a>)'
            ]

            rom_match = None
            for pattern in rom_patterns:
                rom_match = re.search(pattern, im_content, re.DOTALL)
                if rom_match:
                    print(f"  使用模式找到ROM内容")
                    break

            if not rom_match:
                print(f"  错误: 在IM电路中未找到ROM内容")
                # 调试：输出IM电路的部分内容
                lines = im_content.split('\n')
                for i, line in enumerate(lines):
                    if 'addr/data' in line or 'contents' in line:
                        print(f"  可能相关的行 {i}: {line[:200]}...")
                return False

            # 提取并替换机器码
            # rom_match.group(2) 是原来的机器码内容
            old_machine_code = rom_match.group(2).strip()

            # 准备新的机器码内容
            # 确保机器码格式正确：每行一个32位十六进制数
            machine_code_lines = machine_code.strip().split('\n')
            # 跳过"v2.0 raw"行（如果有的话）
            if machine_code_lines and machine_code_lines[0].startswith('v2.0'):
                machine_code_lines = machine_code_lines[1:]

            # 清理每行，确保是8字符的十六进制数
            cleaned_machine_code = []
            for line in machine_code_lines:
                line = line.strip()
                if line:
                    # 确保是8字符的十六进制格式
                    if len(line) < 8:
                        line = line.zfill(8)
                    elif len(line) > 8:
                        line = line[:8]
                    cleaned_machine_code.append(line)

            new_machine_code = '\n'.join(cleaned_machine_code)

            print(f"  原始机器码行数: {len(old_machine_code.split()) if old_machine_code else 0}")
            print(f"  新机器码行数: {len(cleaned_machine_code)}")
            if cleaned_machine_code:
                print(f"  前3条新机器码: {cleaned_machine_code[:3]}")

            # 替换ROM内容
            replacement = rom_match.group(1) + new_machine_code + rom_match.group(3)
            new_im_content = im_content[:rom_match.start()] + replacement + im_content[rom_match.end():]

            # 替换整个文件中的IM电路部分
            new_content = content[:im_match.start()] + new_im_content + content[im_match.end():]

            # 验证替换是否成功
            if new_content == content:
                print(f"  警告: 电路文件内容未改变，可能替换失败")
                return False

            # 写回文件
            with open(circuit_path, 'w', encoding='utf-8') as f:
                f.write(new_content)

            # 验证机器码是否成功注入
            with open(circuit_path, 'r', encoding='utf-8') as f:
                updated_content = f.read()
                # 检查新的机器码是否在文件中
                if any(line in updated_content for line in cleaned_machine_code[:3] if cleaned_machine_code):
                    print(f"  ✓ 机器码成功注入到 {os.path.basename(circuit_path)}")
                    return True
                else:
                    print(f"  错误: 机器码未成功注入到电路文件")
                    # 调试：检查实际写入的内容
                    updated_im_match = re.search(im_circuit_pattern, updated_content, re.DOTALL)
                    if updated_im_match:
                        updated_rom_match = re.search(rom_patterns[0], updated_im_match.group(0), re.DOTALL)
                        if updated_rom_match:
                            actual_code = updated_rom_match.group(2).strip()
                            print(f"  实际写入的机器码前3行: {actual_code.split()[:3] if actual_code else '空'}")
                    return False

        except Exception as e:
            print(f"注入机器码到电路失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def run_logisim_circuit(self, circuit_path, output_file):
        """
        运行Logisim电路并捕获输出
        """
        try:
            cmd = [
                'java', '-jar', self.logisim_path,
                circuit_path, '-tty', 'table'
            ]

            print(f"  运行 {os.path.basename(circuit_path)}...")

            # 增加运行时间，确保CPU有足够时间执行
            with open(output_file, 'w', encoding='utf-8') as f:
                process = subprocess.Popen(
                    cmd,
                    stdout=f,
                    stderr=subprocess.PIPE,
                    text=True
                )

                # 等待足够长时间让电路执行
                time.sleep(15)  # 增加到15秒

                # 终止进程
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()

            # 检查输出文件
            if os.path.exists(output_file):
                with open(output_file, 'r') as f:
                    lines = f.readlines()
                    if lines:
                        print(f"  ✓ {os.path.basename(circuit_path)} 输出 {len(lines)} 行")
                        # 显示更多输出用于调试
                        print(f"    前10行输出:")
                        for i, line in enumerate(lines[:10]):
                            print(f"      {i + 1}: {line.strip()}")

                        # 检查是否有halt信号
                        halt_lines = [line for line in lines if 'halt' in line.lower()]
                        if halt_lines:
                            print(f"    发现halt信号: {halt_lines[0].strip()}")
                    else:
                        print(f"  ! {os.path.basename(circuit_path)} 输出为空")
                        # 检查stderr
                        if process.stderr:
                            stderr_output = process.stderr.read()
                            if stderr_output:
                                print(f"    stderr: {stderr_output[:500]}")

                return True
            else:
                print(f"  ! {os.path.basename(circuit_path)} 输出文件未生成")
                return False

        except Exception as e:
            print(f"运行Logisim电路失败: {e}")
            return False

    def compare_outputs(self):
        """
        比较两个CPU的输出结果，考虑使能信号
        输出顺序: Instr, pc, RegWrite, RegAddr, RegData, MemWrite, MemAddr, MemData
        每个32位信号被分成8个4位字段
        """
        try:
            # 读取输出文件
            with open(self.my_output, 'r') as f:
                my_output = f.readlines()
            with open(self.ref_output, 'r') as f:
                ref_output = f.readlines()

            # 比较行数
            if len(my_output) != len(ref_output):
                print(f"  我的CPU输出行数: {len(my_output)}")
                print(f"  参考CPU输出行数: {len(ref_output)}")
                return False, f"输出行数不同: 我的输出{len(my_output)}行, 参考输出{len(ref_output)}行"

            # 逐行比较
            for i, (my_line, ref_line) in enumerate(zip(my_output, ref_output)):
                my_parts = my_line.strip().split()
                ref_parts = ref_line.strip().split()

                # 检查行格式是否一致
                if len(my_parts) != len(ref_parts):
                    return False, f"第{i + 1}行字段数不同:\n我的输出: {my_line.strip()} (字段数: {len(my_parts)})\n参考输出: {ref_line.strip()} (字段数: {len(ref_parts)})"

                # 根据输出顺序解析信号
                # 每个32位信号被分成8个4位字段
                # 计算每个信号的字段范围
                # Instr: 字段 0-7 (8个字段，32位)
                # pc: 字段 8-15 (8个字段，32位)
                # RegWrite: 字段 16 (1个字段，1位)
                # RegAddr: 字段 17-18 (2个字段，5位)
                # RegData: 字段 19-26 (8个字段，32位)
                # MemWrite: 字段 27 (1个字段，1位)
                # MemAddr: 字段 28-35 (8个字段，32位)
                # MemData: 字段 36-43 (8个字段，32位)

                # 提取使能信号
                my_reg_write = my_parts[16].lower()
                ref_reg_write = ref_parts[16].lower()
                my_mem_write = my_parts[27].lower()
                ref_mem_write = ref_parts[27].lower()

                # 检查是否为nop指令
                # nop指令的机器码是0x00000000
                my_instr = ''.join(my_parts[0:8])  # 合并Instr字段
                ref_instr = ''.join(ref_parts[0:8])  # 合并Instr字段

                is_nop = (my_instr == '00000000000000000000000000000000' and
                          ref_instr == '00000000000000000000000000000000')

                # 比较所有信号，但根据使能信号忽略不重要的信号
                for j in range(len(my_parts)):
                    skip_comparison = False
                    signal_name = ""

                    # 确定信号名称和范围
                    if 0 <= j <= 7:
                        signal_name = "Instr"
                    elif 8 <= j <= 15:
                        signal_name = "PC"
                    elif j == 16:
                        signal_name = "RegWrite"
                        # 如果是nop指令，允许RegWrite不同
                        if is_nop and my_reg_write != ref_reg_write:
                            # 检查是否一方为0，另一方为1但RegAddr为0
                            my_reg_addr = ''.join(my_parts[17:19])  # 合并RegAddr字段
                            ref_reg_addr = ''.join(ref_parts[17:19])  # 合并RegAddr字段

                            # 如果一方为0，另一方为1且RegAddr为0，允许
                            if ((my_reg_write == '0' and ref_reg_write == '1' and ref_reg_addr == '00000') or
                                    (my_reg_write == '1' and ref_reg_write == '0' and my_reg_addr == '00000')):
                                skip_comparison = True
                    elif 17 <= j <= 18:
                        signal_name = "RegAddr"
                        # 如果RegWrite=0，跳过RegAddr比较
                        if my_reg_write == '0' and ref_reg_write == '0':
                            skip_comparison = True
                        # 如果是nop指令且RegWrite不同，跳过比较
                        elif is_nop and my_reg_write != ref_reg_write:
                            skip_comparison = True
                    elif 19 <= j <= 26:
                        signal_name = "RegData"
                        # 如果RegWrite=0，跳过RegData比较
                        if my_reg_write == '0' and ref_reg_write == '0':
                            skip_comparison = True
                        # 如果是nop指令且RegWrite不同，跳过比较
                        elif is_nop and my_reg_write != ref_reg_write:
                            skip_comparison = True
                    elif j == 27:
                        signal_name = "MemWrite"
                    elif 28 <= j <= 35:
                        signal_name = "MemAddr"
                        # 如果MemWrite=0，跳过MemAddr比较
                        if my_mem_write == '0' and ref_mem_write == '0':
                            skip_comparison = True
                    elif 36 <= j <= 43:
                        signal_name = "MemData"
                        # 如果MemWrite=0，跳过MemData比较
                        if my_mem_write == '0' and ref_mem_write == '0':
                            skip_comparison = True
                    else:
                        # 未知字段，跳过比较
                        continue

                    # 跳过比较或在需要时比较
                    if not skip_comparison and my_parts[j] != ref_parts[j]:
                        # 检查是否是因为使能信号不同导致的
                        if signal_name in ["RegAddr", "RegData"] and (my_reg_write != ref_reg_write):
                            return False, f"第{i + 1}行{signal_name}[字段{j}]不同且RegWrite使能信号也不同:\n我的RegWrite: {my_reg_write}, 参考RegWrite: {ref_reg_write}\n我的{signal_name}: {my_parts[j]}\n参考{signal_name}: {ref_parts[j]}"
                        elif signal_name in ["MemAddr", "MemData"] and (my_mem_write != ref_mem_write):
                            return False, f"第{i + 1}行{signal_name}[字段{j}]不同且MemWrite使能信号也不同:\n我的MemWrite: {my_mem_write}, 参考MemWrite: {ref_mem_write}\n我的{signal_name}: {my_parts[j]}\n参考{signal_name}: {ref_parts[j]}"
                        else:
                            return False, f"第{i + 1}行{signal_name}[字段{j}]不同:\n我的输出: {my_parts[j]}\n参考输出: {ref_parts[j]}"

            return True, "所有输出完全匹配"

        except Exception as e:
            return False, f"比较输出时出错: {e}"

    def cleanup(self):
        """
        清理临时文件
        """
        temp_files = [
            self.asm_file,
            self.machine_code_file,
            self.my_output,
            self.ref_output
        ]

        for file in temp_files:
            if os.path.exists(file):
                try:
                    os.remove(file)
                except:
                    pass

    def run_single_test(self, test_id, num_instructions):
        """
        执行单次测试
        """
        print(f"测试 #{test_id}: 生成{num_instructions}条指令")

        # 1. 生成MIPS代码 - 传入test_id确保每次生成不同的代码
        asm_code = self.generate_mips_code(num_instructions, test_id)
        print("  ✓ MIPS代码生成完成")

        # 2. 生成机器码
        if not self.generate_machine_code(asm_code):
            return False, "机器码生成失败"
        print("  ✓ 机器码生成完成")

        # 读取机器码
        with open(self.machine_code_file, 'r') as f:
            machine_code = f.read().strip()

        # 显示前几条机器码（用于验证是否不同）
        machine_lines = machine_code.split('\n')
        if len(machine_lines) > 1:
            print(f"  前5条机器码: {' '.join(machine_lines[1:6])}")  # 跳过第一行"v2.0 raw"
        else:
            print(f"  机器码内容: {machine_code[:100]}...")

        # 3. 注入到两个CPU电路
        if not self.inject_machine_code_to_circuit(self.my_cpu_path, machine_code):
            return False, "注入到我的CPU失败"
        if not self.inject_machine_code_to_circuit(self.ref_cpu_path, machine_code):
            return False, "注入到参考CPU失败"

        # 4. 运行两个CPU
        if not self.run_logisim_circuit(self.my_cpu_path, self.my_output):
            return False, "我的CPU运行失败"
        if not self.run_logisim_circuit(self.ref_cpu_path, self.ref_output):
            return False, "参考CPU运行失败"

        # 5. 比较结果
        success, message = self.compare_outputs()

        if success:
            print(f"  ✓ 测试通过")
            return True, "AC"
        else:
            print(f"  ✗ 测试失败: {message}")
            return False, f"WA: {message}"

    def run_batch_tests(self, num_tests):
        """
        运行批量测试
        """
        print(f"开始运行{num_tests}次自动化测试")
        print("=" * 50)

        passed = 0
        failed = 0

        for i in range(1, num_tests + 1):
            # 随机生成指令数量 (1-200条)
            num_instructions = random.randint(1, 500)

            success, message = self.run_single_test(i, num_instructions)

            if success:
                passed += 1
            else:
                failed += 1
                # 保存出错的测试用例
                error_asm_file = f"error_test_{i}.asm"
                with open(error_asm_file, 'w') as f:
                    f.write(f"// 测试 #{i} - 出错的汇编代码\n")
                    with open(self.asm_file, 'r') as src:
                        f.write(src.read())
                print(f"  ! 出错的测试用例已保存到: {error_asm_file}")

                # 保存机器码文件
                error_machine_file = f"error_machine_{i}.txt"
                with open(error_machine_file, 'w') as f:
                    with open(self.machine_code_file, 'r') as src:
                        f.write(src.read())
                print(f"  ! 机器码文件已保存到: {error_machine_file}")

                # 第一次失败就停止，方便调试
                print(f"\n首次失败出现在测试 #{i}")
                print("是否继续测试? (y/n): ", end="")
                choice = input().strip().lower()
                if choice != 'y':
                    break

            print("-" * 30)

        # 输出统计结果
        print("=" * 50)
        print(f"测试完成!")
        print(f"通过: {passed} 次")
        print(f"失败: {failed} 次")
        print(f"总计: {passed + failed} 次")

        if failed == 0:
            print("🎉 所有测试通过! 你的CPU设计正确!")
        else:
            print("❌ 存在测试失败，请检查CPU设计")


def main():
    # 在程序开始时设置随机种子
    random.seed(time.time())

    # 创建测试器实例
    evaluator = MIPSCPUEvaluator()

    try:
        # 获取测试次数
        print("Logisim单周期CPU自动化测试系统")
        print("支持的指令: add, sub, ori, lw, sw, beq, lui, nop")
        print("地址限制: PC < 0x6000, DM < 0x2FFF")
        print("=" * 50)

        num_tests = int(input("请输入要运行的测试次数: "))

        # 运行批量测试
        evaluator.run_batch_tests(num_tests)

    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"程序运行出错: {e}")



if __name__ == "__main__":
    main()