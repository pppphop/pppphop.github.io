import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import java.util.Arrays;

public class GameManager {
    private Map<String, Adventurer> adventurers = new HashMap<>();
    private Shop shop = new Shop();
    private EmployerManager employerManager;

    public GameManager() {
        employerManager = new EmployerManager(adventurers);
    }

    public void start() {
        ArrayList<ArrayList<String>> inputInfo = new ArrayList<>(); // 解析后的输入将会存进该容器中, 类似于c语言的二维数组
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine().trim());
        for (int i = 0; i < n; i++) {
            String nextLine = scanner.nextLine();
            String[] strings = nextLine.trim().split(" +");
            inputInfo.add(new ArrayList<>(Arrays.asList(strings)));
            //processCmd(strings);
        }
        for (int i = 0; i < n; i++) {
            ArrayList<String> stringList = inputInfo.get(i);
            String[] strings = stringList.toArray(new String[0]);
            processCmd(strings);
        }
    }

    public void processCmd(String[] strings) {
        String cmd = strings[0];
        switch (strings[0]) {
            case "aa":
                addAdventurer(strings[1]);
                break;
            case "ab":
                addBottle(strings[1], strings[2], strings[3], strings[4]);
                break;
            case "ae":
                addEquipment(strings[1], strings[2], strings[3], strings[4]);
                break;
            case "ls":
                learnSpell(strings[1], strings[2], strings[3], strings[4], strings[5]);
                break;
            case "ri":
                removeItem(strings[1], strings[2]);
                break;
            case "ti":
                takeItem(strings[1], strings[2]);
                break;
            case "use":
                useItem(strings[1], strings[2], strings[3]);
                break;
            case "bi":
                buyItem(strings[1], strings[2], strings[3]);
                break;
            case "fight":
                fight(strings);
                break;
            case "ar":
                addRelation(strings[1],strings[2]);
                break;
            case "rr":
                removeRelation(strings[1],strings[2]);
                break;
            case "lr":
                loadRelation(strings);
                break;
            default:
        }
    }

    public void addAdventurer(String name) {
        adventurers.put(name,new Adventurer(name));
    }

    public void addBottle(String advId, String bottleId, String type, String effectStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int effectnow = Integer.parseInt(effectStr);
        Bottle bot = Factory.createBottle(type, bottleId, effectnow);
        if (bot != null) {
            adv.addBottle(bot);
        }
    }

    public Adventurer getAdventurer(String advId) {
        return adventurers.get(advId);
    }

    public void addEquipment(String advId, String equipmentId,String type,String ceStr) {
        Adventurer adv = getAdventurer(advId);
        int ce = Integer.parseInt(ceStr);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        Equipment equip = Factory.createEquipment(type, equipmentId, ce);
        adv.addEquipment(equip);
    }

    public void learnSpell(String advId,String speId,String type,String manaStr,String powStr) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        int manaCost = Integer.parseInt(manaStr);
        int power = Integer.parseInt(powStr);
        Spell spell = Factory.createSpell(type, speId, manaCost, power);;
        if (spell != null) {
            adv.addspell(spell);
        }
    }

    public void removeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String nowdeltype = adv.delitem(itemId);
        System.out.println(nowdeltype);
    }

    public void takeItem(String advId, String itemId) {
        Adventurer adv = getAdventurer(advId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        String type = adv.additem(itemId);
        System.out.println(type);
    }

    public void useItem(String advId,String usableId,String targetId) {
        Adventurer adv = getAdventurer(advId);
        Adventurer target = getAdventurer(targetId);
        if (adv.checkdead() == 1) {
            System.out.println(adv.getId() + " is dead!");
            return;
        }
        if (target.checkdead() == 1) {
            System.out.println(target.getId() + " is dead!");
            return;
        }
        int oldHp = target.gethitpoint();
        Item item = adv.findItem(usableId);
        if (item != null) {
            if (isNegativeEffect(item) && employerManager.isSuperior(targetId,advId)) {
                System.out.println("That's my boss!");
                return;
            }
            else if (!isNegativeEffect(item) && !employerManager.isAlly(advId,targetId)) {
                System.out.println("That's not my ally");
                return;
            }
        }
        boolean suc = adv.useitem(usableId, target);
        if (!suc) {
            System.out.println(adv.getId() + " fail to use " + usableId);
        } else {
            int a = target.gethitpoint();
            int b = target.getatk();
            int c = target.getdef();
            int d = target.getmana();
            System.out.println(target.getId() + " " + a + " " + b + " " + c + " " + d);
            if (a <= 0) {
                employerManager.handleDeath(targetId);
            }
            checkifAid(targetId,oldHp,a);
        }

    }

    public int adventurernum() {
        return adventurers.size();
    }

    public void buyItem(String advId,String itemId,String type) {
        Adventurer adv = getAdventurer(advId);
        if (adv == null || adv.checkdead() == 1) {
            System.out.println(advId + " is dead!");
            return;
        }
        int usemoney = Math.min(adv.getMoney(),100);
        Item item = shop.buy(type,itemId,usemoney);
        if (item != null) {
            adv.subMoney(usemoney);
            if (item instanceof Bottle) {
                adv.addBottle((Bottle)item);
            }
            else if (item instanceof Equipment) {
                adv.addEquipment((Equipment) item);
            }
        }
        System.out.println(adv.getMoney());
    }

    public void fight(String[] strings) {
        String atkerId = strings[1];
        int k = Integer.parseInt(strings[2]);
        Adventurer atker = getAdventurer(atkerId);
        if (atker == null || atker.checkdead() == 1) {
            System.out.println(atkerId + " is dead!");
            return;
        }
        ArrayList<Adventurer> targets = new ArrayList<>();
        ArrayList<Integer> oldHps = new ArrayList<>();
        for (int i = 1;i <= k;i++) {
            String targetId = strings[i + 2];
            Adventurer target = getAdventurer(targetId);
            if (target != null && target.checkdead() == 0) {
                if (employerManager.isSuperior(targetId,atkerId)) {
                    System.out.println("That's my boss!");
                    return;
                }
                oldHps.add(target.gethitpoint());
                targets.add(target);
            }
        }
        BattleManager battle = new BattleManager(atker,targets);
        boolean success = battle.fight();
        if (!success) {
            System.out.println("Adventurer " + atkerId + " defeated");
        }
        else {
            for (int i = 0; i < targets.size(); i++) {
                Adventurer target = targets.get(i);
                int newHp = target.gethitpoint();
                System.out.printf("%d ", newHp);
                /*if (newHp <= 0) {
                    employerManager.handleDeath(target.getId());
                }

                checkifAid(target.getId(), oldHps.get(i), newHp);*/
            }
            System.out.print("\n");
            for (int i = 0; i < targets.size(); i++) {
                Adventurer target = targets.get(i);
                int newHp = target.gethitpoint();
                if (newHp <= 0) {
                    employerManager.handleDeath(target.getId());
                }
                //checkifAid(target.getId(), oldHps.get(i), newHp);
            }
            for (int i = 0; i < targets.size(); i++) {
                Adventurer target = targets.get(i);
                int newHp = target.gethitpoint();
                checkifAid(target.getId(), oldHps.get(i), newHp);
            }
            //System.out.print("\n");
        }
    }

    public void addRelation(String bossId,String employeeId) {
        Adventurer boss = getAdventurer(bossId);
        Adventurer employee = getAdventurer(employeeId);
        if (boss == null  || boss.checkdead() == 1) {
            System.out.println(bossId + " is dead!");
            return;
        }
        else if (employee == null || employee.checkdead() == 1) {
            System.out.println(employeeId + " is dead!");
            return;
        }
        employerManager.addEmployment(bossId,employeeId);
    }

    public void removeRelation(String bossId,String employeeId) {
        Adventurer boss = getAdventurer(bossId);
        Adventurer employee = getAdventurer(employeeId);
        if (boss == null  || boss.checkdead() == 1) {
            System.out.println(bossId + " is dead!");
            return;
        }
        else if (employee == null || employee.checkdead() == 1) {
            System.out.println(employeeId + " is dead!");
            return;
        }
        employerManager.removeEmployment(bossId,employeeId);
    }

    private void checkifAid(String targetId, int oldHp, int newHp) {
        if (newHp > 0 && newHp <= oldHp / 2) {
            AidEvent(targetId);
        }
    }

    private void AidEvent(String targetId) {
        Set<String> subordinates = employerManager.getAllSubordinates(targetId);
        int successCount = 0;
        Adventurer target = adventurers.get(targetId);

        if (target == null || target.checkdead() == 1) {
            return;
        }

        int oldHp = target.gethitpoint();
        for (String subordinateId : subordinates) {
            Adventurer subordinate = adventurers.get(subordinateId);
            if (subordinate != null && subordinate.checkdead() == 0
                && subordinate.canuseHealSpell()) {
                HealSpell bestSpell = subordinate.getBestHealSpell();
                if (bestSpell != null) {
                    bestSpell.use(subordinate,target);
                    successCount++;
                }
            }
        }

        if (successCount > 0) {
            System.out.println(targetId + " is helped by " + successCount +
                    " adventurer(s), now Hp is " + target.gethitpoint());
        }

    }

    private boolean isNegativeEffect(Item item) {
        return item instanceof AttackSpell;
    }

    public void loadRelation(String[] strings) {
        StringBuilder inputBuilder = new StringBuilder();
        for (int i = 1; i < strings.length; i++) {
            inputBuilder.append(strings[i]);
            if (i < strings.length - 1) {
                inputBuilder.append(" ");
            }
        }
        String input = inputBuilder.toString();
        Lexer lexer = new Lexer(input);
        Parser parser = new Parser(lexer, employerManager);
        parser.parse();
    }
}
