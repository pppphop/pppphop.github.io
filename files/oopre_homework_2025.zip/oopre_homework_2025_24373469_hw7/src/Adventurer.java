import java.util.ArrayList;
import java.util.LinkedList;

public class Adventurer {
    private String id;
    private int hitpoint;
    private int atk;
    private int def;
    private int mana;
    private int isDead;
    private int money;
    private Weapon weapon;
    private Armour armour;
    private ArrayList<Bottle> bottles;
    private ArrayList<Equipment> equipments;
    private LinkedList<Item> backpack;
    private ArrayList<Spell> spells;

    public Adventurer(String id) {
        this.id = id;
        this.hitpoint = 500;
        this.atk = 1;
        this.def = 0;
        this.mana = 10;
        this.money = 50;
        this.weapon = null;
        this.armour = null;
        this.bottles = new ArrayList<Bottle>();
        this.equipments = new ArrayList<Equipment>();
        this.backpack = new LinkedList<>();
        this.isDead = 0;
        this.spells = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void addBottle(Bottle bottle) {
        bottles.add(bottle);
    }

    public void addEquipment(Equipment equipment) {
        equipments.add(equipment);
    }

    public void addMoney(int money) {
        this.money += money;
    }

    public boolean subMoney(int money) {
        boolean fl = false;
        if (this.money >= money) {
            fl = true;
            this.money -= money;
        }
        return fl;
    }

    public int getMoney() {
        return money;
    }

    public int bottlenum() {
        return bottles.size();
    }

    public int equipmentnum() {
        return equipments.size();
    }

    public int delBottle(String delid) {
        for (Bottle b : bottles) {
            if (b.getId().equals(delid)) {
                int res = b.getEffect();
                bottles.remove(b);
                return res;
            }
        }
        return 0;
    }

    public void delEquipment(String delid) {
        for (Equipment e : equipments) {
            if (e.getId().equals(delid)) {
                equipments.remove(e);
                break;
            }
        }
    }

    public void addhitpoint(int hitpoint) {
        this.hitpoint += hitpoint;
    }

    public void subhitpoint(int hitpoint) {
        this.hitpoint -= hitpoint;
    }

    public void addatk(int atk) {
        this.atk += atk;
    }

    public void subatk(int atk) {
        this.atk -= atk;
    }

    public void adddef(int def) {
        this.def += def;
    }

    public void subdef(int def) {
        this.def -= def;
    }

    public void addmana(int mana) {
        this.mana += mana;
    }

    public void submana(int mana) {
        this.mana -= mana;
    }

    public int gethitpoint() {
        return hitpoint;
    }

    public int getatk() {
        return atk;
    }

    public int getdef() {
        return def;
    }

    public int getmana() {
        return mana;
    }

    public void setatkzero() {
        this.atk = 0;
    }

    public String additem(String item) {
        for (Item i : backpack) {
            if (i.getId().equals(item)) {
                return i.getTypeName();
            }
        }
        String res = "";
        int fl = 0;
        for (Item i : bottles) {
            if (i.getId().equals(item)) {
                res = i.getTypeName();
                fl = 1;
                if (bottlenuminbackpack() >= 10) {
                    removeFirstBottle();
                }
                backpack.add(i);
                break;
            }
        }
        if (fl == 0) {
            for (Item i : equipments) {
                if (i.getId().equals(item)) {
                    res = i.getTypeName();
                    if (i instanceof Weapon) {
                        Weapon newWeapon = (Weapon) i;
                        if (weapon != null) {
                            backpack.remove(weapon);
                        }
                        weapon = newWeapon;
                        backpack.add(i);
                    }
                    else if (i instanceof Armour) {
                        Armour newArmour = (Armour) i;
                        if (armour != null) {
                            backpack.remove(armour);
                        }
                        armour = newArmour;
                        backpack.add(i);
                    }
                    else {
                        backpack.add(i);
                    }
                    break;
                }
            }
        }
        return res;
    }

    public String delitem(String item) {
        String res = "";
        int fl = 0;
        for (Item i : backpack) {
            if (i.getId().equals(item)) {
                res = i.getTypeName();
                fl = 1;
                backpack.remove(i);
                if (i.getTypeName().equals("Equipment") || i.getTypeName().equals("Weapon") ||
                        i.getTypeName().equals("Armour") || i.getTypeName().equals("Sword")
                    || i.getTypeName().equals("Magicbook")) {
                    equipments.remove(i);
                    if (i.getTypeName().equals("Armour") && armour != null
                            && i.getId().equals(armour.getId())) {
                        armour = null;
                    }
                    if ((i.getTypeName().equals("Sword")
                            || i.getTypeName().equals("Magicbook")
                            || i.getTypeName().equals("Weapon"))
                            && weapon != null
                            && i.getId().equals(weapon.getId())) {
                        weapon = null;
                    }
                }
                else {
                    bottles.remove(i);
                }
                break;
            }
        }
        if (fl == 0) {
            for (Equipment e : equipments) {
                if (e.getId().equals(item)) {
                    res = e.getTypeName();
                    equipments.remove(e);
                    break;
                }
            }
            for (Bottle b : bottles) {
                if (b.getId().equals(item)) {
                    res = b.getTypeName();
                    bottles.remove(b);
                    break;
                }
            }
        }
        return res;
    }

    public int backpacknum() {
        return backpack.size();
    }

    public int itemnum() {
        return backpack.size() + spells.size();
    }

    public void setHitpointzero() {
        this.hitpoint = 0;
        this.isDead = 1;
    }

    public int checkdead() {
        if (this.hitpoint <= 0) {
            this.isDead = 1;
        }
        return  this.isDead;
    }

    public boolean useitem(String item,Adventurer target) {
        boolean fl = false;
        if (target.checkdead() == 1) {
            return fl;
        }
        for (Item i : backpack) {
            if (i.getId().equals(item)) {
                if (i.useable()) {
                    fl = i.use(this,target);
                    break;
                }
            }
        }
        if (!fl) {
            for (Item i : spells) {
                if (i.getId().equals(item)) {
                    fl = i.use(this,target);
                    break;
                }
            }
        }
        return fl;
    }

    public void addspell(Spell spell) {
        spells.add(spell);
    }

    public int spellnum() {
        return spells.size();
    }

    public int effectsum() {
        int sum = 0;
        for (Bottle b : bottles) {
            sum += b.getEffect();
        }
        return sum;
    }

    public int cesum() {
        int sum = 0;
        for (Equipment e : equipments) {
            sum += e.getce();
        }
        return sum;
    }

    public Item findItem(String itemId) {
        for (Bottle bottle : bottles) {
            if (bottle.getId().equals(itemId)) {
                return bottle;
            }
        }
        for (Equipment equipment : equipments) {
            if (equipment.getId().equals(itemId)) {
                return equipment;
            }
        }
        for (Spell spell : spells) {
            if (spell.getId().equals(itemId)) {
                return spell;
            }
        }
        return null;
    }

    public Item findUsableItem(String itemId) {
        for (Item item : backpack) {
            if (item.getId().equals(itemId)) {
                return item;
            }
        }
        for (Spell spell : spells) {
            if (spell.getId().equals(itemId)) {
                return spell;
            }
        }
        return null;
    }

    public int bottlenuminbackpack() {
        int cnt = 0;
        for (Item item : backpack) {
            if (item instanceof Bottle) {
                cnt++;
            }
        }
        return cnt;
    }

    private void removeFirstBottle() {
        for (Item item : backpack) {
            if (item instanceof Bottle) {
                backpack.remove(item);
                break;
            }
        }
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public int getFinalAtk() {
        return (weapon != null) ? (atk + weapon.getce()) : atk;
    }

    public int getFinalDef() {
        return (armour != null) ? (def + armour.getce()) : def;
    }

    public boolean canuseHealSpell() {
        for (Spell spell : spells) {
            if (spell instanceof HealSpell && getmana() >= spell.getManaCost()) {
                return true;
            }
        }
        return false;
    }

    public HealSpell getBestHealSpell() {
        HealSpell best = null;
        for (Spell spell : spells) {
            if (spell instanceof HealSpell && getmana() >= spell.getManaCost()) {
                if (best == null ||
                        spell.getPower() > best.getPower() ||
                        (spell.getPower() == best.getPower() &&
                                spell.getManaCost() < best.getManaCost())) {
                    best = (HealSpell) spell;
                }
            }
        }
        return best;
    }

}
