public class Shop {
    public Item buy(String type, String id, int money) {
        int actualmoney = Math.min(money,100);
        return Factory.createItem(type,id,actualmoney);
    }
}
