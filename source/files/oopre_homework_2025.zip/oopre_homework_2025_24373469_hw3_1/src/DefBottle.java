public class DefBottle extends Bottle {

    public DefBottle(String id, int effect) {
        super(id, effect);
    }

    @Override
    public String getName() {
        return "DefBottle";
    }

    @Override
    public boolean use(Adventurer user, Adventurer target) {
        if (target.checkdead() == 0 && user.checkdead() == 0) {
            target.adddef(this.getEffect());
            user.delitem(this.getId());
            user.delBottle(this.getId());
            return true;
        }
        return false;
    }

    @Override
    public String getTypeName() {
        return "DefBottle";
    }
}
