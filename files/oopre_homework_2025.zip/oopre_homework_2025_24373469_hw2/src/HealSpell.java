public class HealSpell extends Spell {

    public HealSpell(String id, int manaCost, int power, String type) {
        super(id, manaCost, power, type);
    }

    @Override
    public String getTypeName() {
        return "HealSpell";
    }

    @Override
    public void use(Adventurer user, Adventurer target) {
        if (user.getmana() >= this.getManaCost() && target.checkdead() == 0) {
            user.submana(this.getManaCost());
            target.addhitpoint(this.getPower());

        }
    }
}
